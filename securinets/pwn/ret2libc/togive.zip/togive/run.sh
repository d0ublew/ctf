#!/bin/bash
timeout 10 cat | env -i ./main