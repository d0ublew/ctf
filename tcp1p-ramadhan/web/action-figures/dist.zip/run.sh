#!/bin/bash

docker compose --compatibility up --build
