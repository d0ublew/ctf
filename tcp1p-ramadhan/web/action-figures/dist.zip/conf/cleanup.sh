#!/bin/bash

rm -rf /chall/*
cp -r /root/dist_cleanup/* /chall/
chmod -R 777 /chall/