package androidx.core.widget;

/* renamed from: androidx.core.widget.a */
public final /* synthetic */ class C0711a implements Runnable {

    /* renamed from: j */
    public final /* synthetic */ ContentLoadingProgressBar f264j;

    public /* synthetic */ C0711a(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f264j = contentLoadingProgressBar;
    }

    public final void run() {
        this.f264j.showOnUiThread();
    }
}
