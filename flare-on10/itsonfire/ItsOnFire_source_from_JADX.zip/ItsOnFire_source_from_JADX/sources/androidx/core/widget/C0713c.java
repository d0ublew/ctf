package androidx.core.widget;

/* renamed from: androidx.core.widget.c */
public final /* synthetic */ class C0713c implements Runnable {

    /* renamed from: j */
    public final /* synthetic */ ContentLoadingProgressBar f266j;

    public /* synthetic */ C0713c(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f266j = contentLoadingProgressBar;
    }

    public final void run() {
        this.f266j.lambda$new$0();
    }
}
