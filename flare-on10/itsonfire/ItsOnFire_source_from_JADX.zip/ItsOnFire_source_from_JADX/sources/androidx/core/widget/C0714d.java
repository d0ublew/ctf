package androidx.core.widget;

/* renamed from: androidx.core.widget.d */
public final /* synthetic */ class C0714d implements Runnable {

    /* renamed from: j */
    public final /* synthetic */ ContentLoadingProgressBar f267j;

    public /* synthetic */ C0714d(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f267j = contentLoadingProgressBar;
    }

    public final void run() {
        this.f267j.lambda$new$1();
    }
}
