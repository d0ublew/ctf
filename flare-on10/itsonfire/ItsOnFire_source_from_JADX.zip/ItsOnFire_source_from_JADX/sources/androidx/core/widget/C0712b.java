package androidx.core.widget;

/* renamed from: androidx.core.widget.b */
public final /* synthetic */ class C0712b implements Runnable {

    /* renamed from: j */
    public final /* synthetic */ ContentLoadingProgressBar f265j;

    public /* synthetic */ C0712b(ContentLoadingProgressBar contentLoadingProgressBar) {
        this.f265j = contentLoadingProgressBar;
    }

    public final void run() {
        this.f265j.hideOnUiThread();
    }
}
