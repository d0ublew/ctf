package androidx.core.graphics;

import android.graphics.Bitmap;
import android.graphics.BlendMode;
import android.graphics.Canvas;
import android.graphics.ColorSpace;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import androidx.annotation.DoNotInline;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.annotation.VisibleForTesting;

public final class BitmapCompat {

    @RequiresApi(17)
    public static class Api17Impl {
        private Api17Impl() {
        }

        @DoNotInline
        public static boolean hasMipMap(Bitmap bitmap) {
            return bitmap.hasMipMap();
        }

        @DoNotInline
        public static void setHasMipMap(Bitmap bitmap, boolean z) {
            bitmap.setHasMipMap(z);
        }
    }

    @RequiresApi(19)
    public static class Api19Impl {
        private Api19Impl() {
        }

        @DoNotInline
        public static int getAllocationByteCount(Bitmap bitmap) {
            return bitmap.getAllocationByteCount();
        }
    }

    @RequiresApi(27)
    public static class Api27Impl {
        private Api27Impl() {
        }

        @DoNotInline
        public static Bitmap copyBitmapIfHardware(Bitmap bitmap) {
            if (bitmap.getConfig() != Bitmap.Config.HARDWARE) {
                return bitmap;
            }
            Bitmap.Config config = Bitmap.Config.ARGB_8888;
            if (Build.VERSION.SDK_INT >= 31) {
                config = Api31Impl.getHardwareBitmapConfig(bitmap);
            }
            return bitmap.copy(config, true);
        }

        @DoNotInline
        public static Bitmap createBitmapWithSourceColorspace(int i, int i2, Bitmap bitmap, boolean z) {
            Bitmap.Config config = bitmap.getConfig();
            ColorSpace colorSpace = bitmap.getColorSpace();
            ColorSpace colorSpace2 = ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB);
            if (z && !bitmap.getColorSpace().equals(colorSpace2)) {
                config = Bitmap.Config.RGBA_F16;
                colorSpace = colorSpace2;
            } else if (bitmap.getConfig() == Bitmap.Config.HARDWARE) {
                config = Bitmap.Config.ARGB_8888;
                if (Build.VERSION.SDK_INT >= 31) {
                    config = Api31Impl.getHardwareBitmapConfig(bitmap);
                }
            }
            return Bitmap.createBitmap(i, i2, config, bitmap.hasAlpha(), colorSpace);
        }

        @DoNotInline
        public static boolean isAlreadyF16AndLinear(Bitmap bitmap) {
            return bitmap.getConfig() == Bitmap.Config.RGBA_F16 && bitmap.getColorSpace().equals(ColorSpace.get(ColorSpace.Named.LINEAR_EXTENDED_SRGB));
        }
    }

    @RequiresApi(29)
    public static class Api29Impl {
        private Api29Impl() {
        }

        @DoNotInline
        public static void setPaintBlendMode(Paint paint) {
            paint.setBlendMode(BlendMode.SRC);
        }
    }

    @RequiresApi(31)
    public static class Api31Impl {
        private Api31Impl() {
        }

        @DoNotInline
        public static Bitmap.Config getHardwareBitmapConfig(Bitmap bitmap) {
            return C0642a.m54a(bitmap).getFormat() == 22 ? Bitmap.Config.RGBA_F16 : Bitmap.Config.ARGB_8888;
        }
    }

    private BitmapCompat() {
    }

    @NonNull
    public static Bitmap createScaledBitmap(@NonNull Bitmap bitmap, int i, int i2, @Nullable Rect rect, boolean z) {
        int i3;
        int i4;
        Bitmap bitmap2;
        Bitmap bitmap3 = bitmap;
        int i5 = i;
        int i6 = i2;
        Rect rect2 = rect;
        if (i5 <= 0 || i6 <= 0) {
            throw new IllegalArgumentException("dstW and dstH must be > 0!");
        } else if (rect2 == null || (!rect.isEmpty() && rect2.left >= 0 && rect2.right <= bitmap.getWidth() && rect2.top >= 0 && rect2.bottom <= bitmap.getHeight())) {
            Bitmap copyBitmapIfHardware = Api27Impl.copyBitmapIfHardware(bitmap);
            int width = rect2 != null ? rect.width() : bitmap.getWidth();
            int height = rect2 != null ? rect.height() : bitmap.getHeight();
            float f = ((float) i5) / ((float) width);
            float f2 = ((float) i6) / ((float) height);
            int i7 = rect2 != null ? rect2.left : 0;
            int i8 = rect2 != null ? rect2.top : 0;
            if (i7 == 0 && i8 == 0 && i5 == bitmap.getWidth() && i6 == bitmap.getHeight()) {
                return (!bitmap.isMutable() || bitmap3 != copyBitmapIfHardware) ? copyBitmapIfHardware : bitmap3.copy(bitmap.getConfig(), true);
            }
            Paint paint = new Paint(1);
            paint.setFilterBitmap(true);
            Api29Impl.setPaintBlendMode(paint);
            if (width == i5 && height == i6) {
                Bitmap createBitmap = Bitmap.createBitmap(i5, i6, copyBitmapIfHardware.getConfig());
                new Canvas(createBitmap).drawBitmap(copyBitmapIfHardware, (float) (-i7), (float) (-i8), paint);
                return createBitmap;
            }
            double log = Math.log(2.0d);
            int i9 = (f > 1.0f ? 1 : (f == 1.0f ? 0 : -1));
            int i10 = i7;
            double log2 = Math.log((double) f) / log;
            int ceil = (int) (i9 > 0 ? Math.ceil(log2) : Math.floor(log2));
            int ceil2 = (int) (f2 > 1.0f ? Math.ceil(Math.log((double) f2) / log) : Math.floor(Math.log((double) f2) / log));
            Bitmap bitmap4 = null;
            if (!z || Api27Impl.isAlreadyF16AndLinear(bitmap)) {
                i4 = i10;
                i3 = 0;
            } else {
                Bitmap createBitmapWithSourceColorspace = Api27Impl.createBitmapWithSourceColorspace(ceil > 0 ? sizeAtStep(width, i5, 1, ceil) : width, ceil2 > 0 ? sizeAtStep(height, i6, 1, ceil2) : height, bitmap3, true);
                new Canvas(createBitmapWithSourceColorspace).drawBitmap(copyBitmapIfHardware, (float) (-i10), (float) (-i8), paint);
                i3 = 1;
                i8 = 0;
                i4 = 0;
                Bitmap bitmap5 = createBitmapWithSourceColorspace;
                bitmap4 = copyBitmapIfHardware;
                copyBitmapIfHardware = bitmap5;
            }
            Rect rect3 = new Rect(i4, i8, width, height);
            Rect rect4 = new Rect();
            int i11 = ceil;
            int i12 = ceil2;
            while (true) {
                if (i11 == 0 && i12 == 0) {
                    break;
                }
                if (i11 < 0) {
                    i11++;
                } else if (i11 > 0) {
                    i11--;
                }
                if (i12 < 0) {
                    i12++;
                } else if (i12 > 0) {
                    i12--;
                }
                Bitmap bitmap6 = bitmap2;
                Paint paint2 = paint;
                rect4.set(0, 0, sizeAtStep(width, i5, i11, ceil), sizeAtStep(height, i6, i12, ceil2));
                boolean z2 = i11 == 0 && i12 == 0;
                boolean z3 = bitmap4 != null && bitmap4.getWidth() == i5 && bitmap4.getHeight() == i6;
                if (bitmap4 == null || bitmap4 == bitmap3 || ((z && !Api27Impl.isAlreadyF16AndLinear(bitmap4)) || (z2 && (!z3 || i3 != 0)))) {
                    if (!(bitmap4 == bitmap3 || bitmap4 == null)) {
                        bitmap4.recycle();
                    }
                    bitmap2 = Api27Impl.createBitmapWithSourceColorspace(sizeAtStep(width, i5, i11 > 0 ? i3 : i11, ceil), sizeAtStep(height, i6, i12 > 0 ? i3 : i12, ceil2), bitmap3, z && !z2);
                } else {
                    bitmap2 = bitmap4;
                }
                Bitmap bitmap7 = bitmap6;
                Paint paint3 = paint2;
                new Canvas(bitmap2).drawBitmap(bitmap7, rect3, rect4, paint3);
                rect3.set(rect4);
                bitmap4 = bitmap7;
                paint = paint3;
            }
            if (!(bitmap4 == bitmap3 || bitmap4 == null)) {
                bitmap4.recycle();
            }
            return bitmap2;
        } else {
            throw new IllegalArgumentException("srcRect must be contained by srcBm!");
        }
    }

    public static int getAllocationByteCount(@NonNull Bitmap bitmap) {
        return Api19Impl.getAllocationByteCount(bitmap);
    }

    public static boolean hasMipMap(@NonNull Bitmap bitmap) {
        return Api17Impl.hasMipMap(bitmap);
    }

    public static void setHasMipMap(@NonNull Bitmap bitmap, boolean z) {
        Api17Impl.setHasMipMap(bitmap, z);
    }

    @VisibleForTesting
    public static int sizeAtStep(int i, int i2, int i3, int i4) {
        return i3 == 0 ? i2 : i3 > 0 ? i * (1 << (i4 - i3)) : i2 << ((-i3) - 1);
    }
}
