package androidx.core.graphics;

/* renamed from: androidx.core.graphics.a */
public final /* synthetic */ class C0642a {
}
