package androidx.core.provider;

import java.util.Comparator;

/* renamed from: androidx.core.provider.a */
public final /* synthetic */ class C0678a implements Comparator {
    public final int compare(Object obj, Object obj2) {
        return FontProvider.lambda$static$0((byte[]) obj, (byte[]) obj2);
    }
}
