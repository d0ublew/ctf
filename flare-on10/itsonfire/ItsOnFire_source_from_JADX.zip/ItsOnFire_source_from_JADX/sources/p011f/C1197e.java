package p011f;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.content.res.AssetManager;
import android.media.SoundPool;
import android.util.Log;
import androidx.compose.runtime.internal.StabilityInferred;
import com.google.firebase.messaging.Constants;
import java.io.IOException;
import kotlin.Metadata;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;

@StabilityInferred(parameters = 0)
@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000$\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0005\b\u0007\u0018\u0000 \u000e2\u00020\u0001:\u0001\u0007B\u000f\u0012\u0006\u0010\u000b\u001a\u00020\n¢\u0006\u0004\b\f\u0010\rJ\u000e\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002R\u0014\u0010\t\u001a\u00020\u00068\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0007\u0010\b¨\u0006\u000f"}, mo21068d2 = {"Lf/e;", "", "", "id", "", "m", "Landroid/media/SoundPool;", "a", "Landroid/media/SoundPool;", "soundPool", "Landroid/content/Context;", "context", "<init>", "(Landroid/content/Context;)V", "b", "app_release"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: f.e */
public final class C1197e {
    @NotNull

    /* renamed from: b */
    public static final C1198a f531b = new C1198a((DefaultConstructorMarker) null);

    /* renamed from: c */
    public static final int f532c = 8;

    /* renamed from: d */
    public static int f533d = -1;

    /* renamed from: e */
    public static int f534e = -1;

    /* renamed from: f */
    public static int f535f = -1;

    /* renamed from: g */
    public static int f536g = -1;

    /* renamed from: h */
    public static int f537h = -1;

    /* renamed from: i */
    public static int f538i = -1;
    @NotNull

    /* renamed from: a */
    public final SoundPool f539a;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0010\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\b\n\u0002\b\u0018\b\u0003\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0018\u0010\u0019R\"\u0010\u0003\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\u0003\u0010\u0004\u001a\u0004\b\u0005\u0010\u0006\"\u0004\b\u0007\u0010\bR\"\u0010\t\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\t\u0010\u0004\u001a\u0004\b\n\u0010\u0006\"\u0004\b\u000b\u0010\bR\"\u0010\f\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\f\u0010\u0004\u001a\u0004\b\r\u0010\u0006\"\u0004\b\u000e\u0010\bR\"\u0010\u000f\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\u000f\u0010\u0004\u001a\u0004\b\u0010\u0010\u0006\"\u0004\b\u0011\u0010\bR\"\u0010\u0012\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\u0012\u0010\u0004\u001a\u0004\b\u0013\u0010\u0006\"\u0004\b\u0014\u0010\bR\"\u0010\u0015\u001a\u00020\u00028\u0006@\u0006X\u000e¢\u0006\u0012\n\u0004\b\u0015\u0010\u0004\u001a\u0004\b\u0016\u0010\u0006\"\u0004\b\u0017\u0010\b¨\u0006\u001a"}, mo21068d2 = {"Lf/e$a;", "", "", "playerExplodeID", "I", "d", "()I", "j", "(I)V", "invaderExplodeID", "b", "h", "shootID", "e", "k", "damageShelterID", "a", "g", "uhID", "f", "l", "ohID", "c", "i", "<init>", "()V", "app_release"}, mo21069k = 1, mo21070mv = {1, 6, 0})
    /* renamed from: f.e$a */
    public static final class C1198a {
        public C1198a() {
        }

        public /* synthetic */ C1198a(DefaultConstructorMarker defaultConstructorMarker) {
            this();
        }

        /* renamed from: a */
        public final int mo21028a() {
            return C1197e.f536g;
        }

        /* renamed from: b */
        public final int mo21029b() {
            return C1197e.f534e;
        }

        /* renamed from: c */
        public final int mo21030c() {
            return C1197e.f538i;
        }

        /* renamed from: d */
        public final int mo21031d() {
            return C1197e.f533d;
        }

        /* renamed from: e */
        public final int mo21032e() {
            return C1197e.f535f;
        }

        /* renamed from: f */
        public final int mo21033f() {
            return C1197e.f537h;
        }

        /* renamed from: g */
        public final void mo21034g(int i) {
            C1197e.f536g = i;
        }

        /* renamed from: h */
        public final void mo21035h(int i) {
            C1197e.f534e = i;
        }

        /* renamed from: i */
        public final void mo21036i(int i) {
            C1197e.f538i = i;
        }

        /* renamed from: j */
        public final void mo21037j(int i) {
            C1197e.f533d = i;
        }

        /* renamed from: k */
        public final void mo21038k(int i) {
            C1197e.f535f = i;
        }

        /* renamed from: l */
        public final void mo21039l(int i) {
            C1197e.f537h = i;
        }
    }

    public C1197e(@NotNull Context context) {
        Intrinsics.checkNotNullParameter(context, "context");
        SoundPool soundPool = new SoundPool(10, 3, 0);
        this.f539a = soundPool;
        try {
            AssetManager assets = context.getAssets();
            AssetFileDescriptor openFd = assets.openFd("shoot.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd, "assetManager.openFd(\"shoot.ogg\")");
            f535f = soundPool.load(openFd, 0);
            AssetFileDescriptor openFd2 = assets.openFd("invaderexplode.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd2, "assetManager.openFd(\"invaderexplode.ogg\")");
            f534e = soundPool.load(openFd2, 0);
            AssetFileDescriptor openFd3 = assets.openFd("damageshelter.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd3, "assetManager.openFd(\"damageshelter.ogg\")");
            f536g = soundPool.load(openFd3, 0);
            AssetFileDescriptor openFd4 = assets.openFd("playerexplode.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd4, "assetManager.openFd(\"playerexplode.ogg\")");
            f533d = soundPool.load(openFd4, 0);
            AssetFileDescriptor openFd5 = assets.openFd("damageshelter.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd5, "assetManager.openFd(\"damageshelter.ogg\")");
            f536g = soundPool.load(openFd5, 0);
            AssetFileDescriptor openFd6 = assets.openFd("uh.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd6, "assetManager.openFd(\"uh.ogg\")");
            f537h = soundPool.load(openFd6, 0);
            AssetFileDescriptor openFd7 = assets.openFd("oh.ogg");
            Intrinsics.checkNotNullExpressionValue(openFd7, "assetManager.openFd(\"oh.ogg\")");
            f538i = soundPool.load(openFd7, 0);
        } catch (IOException unused) {
            Log.e(Constants.IPC_BUNDLE_KEY_SEND_ERROR, "failed to load sound files");
        }
    }

    /* renamed from: m */
    public final void mo21027m(int i) {
        this.f539a.play(i, 1.0f, 1.0f, 0, 0, 1.0f);
    }
}
