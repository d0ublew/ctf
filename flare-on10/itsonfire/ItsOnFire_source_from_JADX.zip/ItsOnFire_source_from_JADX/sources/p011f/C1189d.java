package p011f;

/* renamed from: f.d */
public final class C1189d {

    /* renamed from: f.d$a */
    public static final class C1190a {

        /* renamed from: a */
        public static final int black = 2131034145;

        /* renamed from: b */
        public static final int purple_200 = 2131034197;

        /* renamed from: c */
        public static final int purple_500 = 2131034198;

        /* renamed from: d */
        public static final int purple_700 = 2131034199;

        /* renamed from: e */
        public static final int teal_200 = 2131034212;

        /* renamed from: f */
        public static final int teal_700 = 2131034213;

        /* renamed from: g */
        public static final int white = 2131034219;
    }

    /* renamed from: f.d$b */
    public static final class C1191b {

        /* renamed from: a */
        public static final int ic_launcher_background = 2131165293;

        /* renamed from: b */
        public static final int ic_launcher_foreground = 2131165294;

        /* renamed from: c */
        public static final int invader1 = 2131165295;

        /* renamed from: d */
        public static final int invader2 = 2131165296;

        /* renamed from: e */
        public static final int playership = 2131165309;
    }

    /* renamed from: f.d$c */
    public static final class C1192c {

        /* renamed from: a */
        public static final int ic_launcher = 2131492864;

        /* renamed from: b */
        public static final int ic_launcher_round = 2131492865;
    }

    /* renamed from: f.d$d */
    public static final class C1193d {

        /* renamed from: a */
        public static final int iv = 2131558401;

        /* renamed from: b */
        public static final int ps = 2131558402;
    }

    /* renamed from: f.d$e */
    public static final class C1194e {

        /* renamed from: A */
        public static final int mn = 2131624016;

        /* renamed from: B */
        public static final int nc = 2131624018;

        /* renamed from: C */
        public static final int oc = 2131624020;

        /* renamed from: D */
        public static final int playerdata = 2131624023;

        /* renamed from: E */
        public static final int prdr = 2131624024;

        /* renamed from: F */
        public static final int project_id = 2131624025;

        /* renamed from: G */
        public static final int roll = 2131624026;

        /* renamed from: H */
        public static final int s1 = 2131624027;

        /* renamed from: I */
        public static final int s2 = 2131624028;

        /* renamed from: J */
        public static final int s3 = 2131624029;

        /* renamed from: K */
        public static final int t1 = 2131624033;

        /* renamed from: L */
        public static final int t2 = 2131624034;

        /* renamed from: M */
        public static final int t3 = 2131624035;

        /* renamed from: N */
        public static final int title = 2131624038;

        /* renamed from: O */
        public static final int w1 = 2131624039;

        /* renamed from: a */
        public static final int ad = 2131623963;

        /* renamed from: b */
        public static final int ag = 2131623964;

        /* renamed from: c */
        public static final int aias = 2131623965;

        /* renamed from: d */
        public static final int alg = 2131623966;

        /* renamed from: e */
        public static final int app_name = 2131623968;

        /* renamed from: f */
        public static final int av = 2131623969;

        /* renamed from: g */
        public static final int bd = 2131623970;

        /* renamed from: h */
        public static final int c2 = 2131623971;

        /* renamed from: i */
        public static final int default_web_client_id = 2131623994;

        /* renamed from: j */
        public static final int es = 2131623996;

        /* renamed from: k */
        public static final int f1 = 2131623997;

        /* renamed from: l */
        public static final int f3 = 2131623998;

        /* renamed from: m */
        public static final int file = 2131624000;

        /* renamed from: n */
        public static final int fo = 2131624001;

        /* renamed from: o */
        public static final int gcm_defaultSenderId = 2131624002;

        /* renamed from: p */
        public static final int google_api_key = 2131624003;

        /* renamed from: q */
        public static final int google_app_id = 2131624004;

        /* renamed from: r */
        public static final int google_crash_reporting_api_key = 2131624005;

        /* renamed from: s */
        public static final int google_storage_bucket = 2131624006;

        /* renamed from: t */
        public static final int iv = 2131624009;

        /* renamed from: u */
        public static final int jn = 2131624010;

        /* renamed from: v */
        public static final int key = 2131624011;

        /* renamed from: w */
        public static final int m1 = 2131624012;

        /* renamed from: x */
        public static final int m2 = 2131624013;

        /* renamed from: y */
        public static final int mc = 2131624014;

        /* renamed from: z */
        public static final int mime = 2131624015;
    }

    /* renamed from: f.d$f */
    public static final class C1195f {

        /* renamed from: a */
        public static final int Theme_Itsonfire = 2131689739;

        /* renamed from: b */
        public static final int Theme_itsonfire = 2131689740;
    }

    /* renamed from: f.d$g */
    public static final class C1196g {

        /* renamed from: a */
        public static final int backup_rules = 2131820544;

        /* renamed from: b */
        public static final int data_extraction_rules = 2131820545;

        /* renamed from: c */
        public static final int provider_paths = 2131820546;
    }
}
