package p011f;

/* renamed from: f.a */
public final class C1186a {

    /* renamed from: a */
    public static final boolean f522a = false;

    /* renamed from: b */
    public static final String f523b = "com.secure.itsonfire";

    /* renamed from: c */
    public static final String f524c = "release";

    /* renamed from: d */
    public static final int f525d = 1;

    /* renamed from: e */
    public static final String f526e = "1.0";
}
