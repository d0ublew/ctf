package p029v;

import java.util.concurrent.Executor;
import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0016\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\bÂ\u0002\u0018\u00002\u00020\u0001B\t\b\u0002¢\u0006\u0004\b\u0006\u0010\u0007J\u0010\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016¨\u0006\b"}, mo21068d2 = {"Lv/a;", "Ljava/util/concurrent/Executor;", "Ljava/lang/Runnable;", "r", "", "execute", "<init>", "()V", "kotlinx-coroutines-play-services"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: v.a */
public final class C2082a implements Executor {
    @NotNull

    /* renamed from: j */
    public static final C2082a f2440j = new C2082a();

    public void execute(@NotNull Runnable runnable) {
        runnable.run();
    }
}
