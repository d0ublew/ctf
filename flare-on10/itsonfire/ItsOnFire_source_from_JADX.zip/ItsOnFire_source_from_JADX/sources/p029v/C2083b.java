package p029v;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import p015j.C1389z;

/* renamed from: v.b */
public final /* synthetic */ class C2083b implements OnCompleteListener {

    /* renamed from: a */
    public final /* synthetic */ C1389z f2441a;

    public /* synthetic */ C2083b(C1389z zVar) {
        this.f2441a = zVar;
    }

    public final void onComplete(Task task) {
        C2084c.m2993f(this.f2441a, task);
    }
}
