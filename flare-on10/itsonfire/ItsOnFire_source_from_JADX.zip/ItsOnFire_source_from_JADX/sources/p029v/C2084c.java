package p029v;

import com.google.android.gms.tasks.CancellationTokenSource;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.RuntimeExecutionException;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskCompletionSource;
import java.util.concurrent.CancellationException;
import java.util.concurrent.Executor;
import kotlin.Deprecated;
import kotlin.DeprecationLevel;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Lambda;
import kotlin.sequences.Sequence;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1226b0;
import p015j.C1234c1;
import p015j.C1236c2;
import p015j.C1278i2;
import p015j.C1309n2;
import p015j.C1324p1;
import p015j.C1327q;
import p015j.C1333r;
import p015j.C1371w;
import p015j.C1383y;
import p015j.C1389z;
import p027t.C2045c;
import p027t.C2046d;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0016\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\t\u001a\u001c\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001\u001a\u001c\u0010\u0004\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0002\u001a&\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0006\u001a\u00020\u0005H\u0007\u001a(\u0010\b\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0002\u001a#\u0010\t\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0002H@ø\u0001\u0000¢\u0006\u0004\b\t\u0010\n\u001a+\u0010\u000b\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0006\u001a\u00020\u0005H@ø\u0001\u0000¢\u0006\u0004\b\u000b\u0010\f\u001a-\u0010\r\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00022\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H@ø\u0001\u0000¢\u0006\u0004\b\r\u0010\f\u0002\u0004\n\u0002\b\u0019¨\u0006\u000e"}, mo21068d2 = {"T", "Lj/c1;", "Lcom/google/android/gms/tasks/Task;", "g", "c", "Lcom/google/android/gms/tasks/CancellationTokenSource;", "cancellationTokenSource", "d", "e", "i", "(Lcom/google/android/gms/tasks/Task;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "h", "(Lcom/google/android/gms/tasks/Task;Lcom/google/android/gms/tasks/CancellationTokenSource;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "j", "kotlinx-coroutines-play-services"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: v.c */
public final class C2084c {

    @Metadata(mo21067d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\n¢\u0006\u0002\b\u0005"}, mo21068d2 = {"<anonymous>", "", "T", "it", "", "invoke"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
    /* renamed from: v.c$a */
    public static final class C2085a extends Lambda implements Function1<Throwable, Unit> {

        /* renamed from: j */
        public final /* synthetic */ CancellationTokenSource f2442j;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C2085a(CancellationTokenSource cancellationTokenSource) {
            super(1);
            this.f2442j = cancellationTokenSource;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((Throwable) obj);
            return Unit.INSTANCE;
        }

        public final void invoke(@Nullable Throwable th) {
            this.f2442j.cancel();
        }
    }

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0001\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\u0003\n\u0000\n\u0002\u0010\u000b\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u000b\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J\u0011\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0001J\u0013\u0010\u0006\u001a\u00028\u0000HAø\u0001\u0000¢\u0006\u0004\b\u0006\u0010\u0007J\t\u0010\t\u001a\u00020\bH\u0001J\u0013\u0010\r\u001a\u00020\f2\b\u0010\u000b\u001a\u0004\u0018\u00010\nH\u0001J\u0019\u0010\t\u001a\u00020\b2\u000e\u0010\u000b\u001a\n\u0018\u00010\u000ej\u0004\u0018\u0001`\u000fH\u0001J8\u0010\u0015\u001a\u00028\u0001\"\u0004\b\u0001\u0010\u00102\u0006\u0010\u0011\u001a\u00028\u00012\u0018\u0010\u0014\u001a\u0014\u0012\u0004\u0012\u00028\u0001\u0012\u0004\u0012\u00020\u0013\u0012\u0004\u0012\u00028\u00010\u0012H\u0001¢\u0006\u0004\b\u0015\u0010\u0016J*\u0010\u001a\u001a\u0004\u0018\u00018\u0001\"\b\b\u0001\u0010\u0017*\u00020\u00132\f\u0010\u0019\u001a\b\u0012\u0004\u0012\u00028\u00010\u0018H\u0003¢\u0006\u0004\b\u001a\u0010\u001bJ\r\u0010\u001c\u001a\u00060\u000ej\u0002`\u000fH\u0001J\u0010\u0010\u001d\u001a\u00028\u0000H\u0001¢\u0006\u0004\b\u001d\u0010\u001eJ\u000b\u0010\u001f\u001a\u0004\u0018\u00010\nH\u0001JB\u0010(\u001a\u00020'2\u0006\u0010 \u001a\u00020\f2\u0006\u0010!\u001a\u00020\f2'\u0010&\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\n¢\u0006\f\b#\u0012\b\b$\u0012\u0004\b\b(\u000b\u0012\u0004\u0012\u00020\b0\"j\u0002`%H\u0001J2\u0010)\u001a\u00020'2'\u0010&\u001a#\u0012\u0015\u0012\u0013\u0018\u00010\n¢\u0006\f\b#\u0012\b\b$\u0012\u0004\b\b(\u000b\u0012\u0004\u0012\u00020\b0\"j\u0002`%H\u0001J\u0013\u0010*\u001a\u00020\bHAø\u0001\u0000¢\u0006\u0004\b*\u0010\u0007J\u0015\u0010,\u001a\u00020+2\n\u0010\u0019\u001a\u0006\u0012\u0002\b\u00030\u0018H\u0001J\u0011\u0010.\u001a\u00020+2\u0006\u0010-\u001a\u00020+H\u0003J\u0011\u00101\u001a\u00020/2\u0006\u00100\u001a\u00020/H\u0003J\t\u00102\u001a\u00020\fH\u0001R\u001a\u00106\u001a\b\u0012\u0004\u0012\u00020/038\u0016X\u0005¢\u0006\u0006\u001a\u0004\b4\u00105R\u0014\u00109\u001a\u00020\f8\u0016X\u0005¢\u0006\u0006\u001a\u0004\b7\u00108R\u0014\u0010:\u001a\u00020\f8\u0016X\u0005¢\u0006\u0006\u001a\u0004\b:\u00108R\u0014\u0010<\u001a\u00020\f8\u0016X\u0005¢\u0006\u0006\u001a\u0004\b;\u00108R\u0018\u0010\u0019\u001a\u0006\u0012\u0002\b\u00030\u00188\u0016X\u0005¢\u0006\u0006\u001a\u0004\b=\u0010>R\u001a\u0010B\u001a\b\u0012\u0004\u0012\u00028\u00000?8\u0016X\u0005¢\u0006\u0006\u001a\u0004\b@\u0010AR\u0014\u0010F\u001a\u00020C8\u0016X\u0005¢\u0006\u0006\u001a\u0004\bD\u0010E\u0002\u0004\n\u0002\b\u0019¨\u0006G"}, mo21068d2 = {"v/c$b", "Lj/c1;", "Lj/y;", "child", "Lj/w;", "X", "x", "(Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "", "cancel", "", "cause", "", "a", "Ljava/util/concurrent/CancellationException;", "Lkotlinx/coroutines/CancellationException;", "R", "initial", "Lkotlin/Function2;", "Lkotlin/coroutines/CoroutineContext$Element;", "operation", "fold", "(Ljava/lang/Object;Lkotlin/jvm/functions/Function2;)Ljava/lang/Object;", "E", "Lkotlin/coroutines/CoroutineContext$Key;", "key", "get", "(Lkotlin/coroutines/CoroutineContext$Key;)Lkotlin/coroutines/CoroutineContext$Element;", "u", "g", "()Ljava/lang/Object;", "l", "onCancelling", "invokeImmediately", "Lkotlin/Function1;", "Lkotlin/ParameterName;", "name", "Lkotlinx/coroutines/CompletionHandler;", "handler", "Lj/p1;", "r", "H", "n", "Lkotlin/coroutines/CoroutineContext;", "minusKey", "context", "plus", "Lj/n2;", "other", "M", "start", "Lkotlin/sequences/Sequence;", "k", "()Lkotlin/sequences/Sequence;", "children", "b", "()Z", "isActive", "isCancelled", "e", "isCompleted", "getKey", "()Lkotlin/coroutines/CoroutineContext$Key;", "Lt/d;", "j", "()Lt/d;", "onAwait", "Lt/c;", "N", "()Lt/c;", "onJoin", "kotlinx-coroutines-play-services"}, mo21069k = 1, mo21070mv = {1, 6, 0})
    /* renamed from: v.c$b */
    public static final class C2086b implements C1234c1<T> {

        /* renamed from: j */
        public final /* synthetic */ C1389z<T> f2443j;

        public C2086b(C1389z<T> zVar) {
            this.f2443j = zVar;
        }

        @NotNull
        /* renamed from: H */
        public C1324p1 mo21593H(@NotNull Function1<? super Throwable, Unit> function1) {
            return this.f2443j.mo21593H(function1);
        }

        @NotNull
        @Deprecated(level = DeprecationLevel.ERROR, message = "Operator '+' on two Job objects is meaningless. Job is a coroutine context element and `+` is a set-sum operator for coroutine contexts. The job to the right of `+` just replaces the job the left of `+`.")
        /* renamed from: M */
        public C1309n2 mo21594M(@NotNull C1309n2 n2Var) {
            return this.f2443j.mo21594M(n2Var);
        }

        @NotNull
        /* renamed from: N */
        public C2045c mo21595N() {
            return this.f2443j.mo21595N();
        }

        @NotNull
        @C1278i2
        /* renamed from: X */
        public C1371w mo21596X(@NotNull C1383y yVar) {
            return this.f2443j.mo21596X(yVar);
        }

        @Deprecated(level = DeprecationLevel.HIDDEN, message = "Since 1.2.0, binary compatibility with versions <= 1.1.x")
        /* renamed from: a */
        public /* synthetic */ boolean mo21597a(Throwable th) {
            return this.f2443j.mo21597a(th);
        }

        /* renamed from: b */
        public boolean mo21543b() {
            return this.f2443j.mo21543b();
        }

        @Deprecated(level = DeprecationLevel.HIDDEN, message = "Since 1.2.0, binary compatibility with versions <= 1.1.x")
        public /* synthetic */ void cancel() {
            this.f2443j.cancel();
        }

        public void cancel(@Nullable CancellationException cancellationException) {
            this.f2443j.cancel(cancellationException);
        }

        /* renamed from: e */
        public boolean mo21600e() {
            return this.f2443j.mo21600e();
        }

        public <R> R fold(R r, @NotNull Function2<? super R, ? super CoroutineContext.Element, ? extends R> function2) {
            return this.f2443j.fold(r, function2);
        }

        @C1236c2
        /* renamed from: g */
        public T mo21553g() {
            return this.f2443j.mo21553g();
        }

        @Nullable
        public <E extends CoroutineContext.Element> E get(@NotNull CoroutineContext.Key<E> key) {
            return this.f2443j.get(key);
        }

        @NotNull
        public CoroutineContext.Key<?> getKey() {
            return this.f2443j.getKey();
        }

        public boolean isCancelled() {
            return this.f2443j.isCancelled();
        }

        @NotNull
        /* renamed from: j */
        public C2046d<T> mo21554j() {
            return this.f2443j.mo21554j();
        }

        @NotNull
        /* renamed from: k */
        public Sequence<C1309n2> mo21602k() {
            return this.f2443j.mo21602k();
        }

        @Nullable
        @C1236c2
        /* renamed from: l */
        public Throwable mo21611l() {
            return this.f2443j.mo21611l();
        }

        @NotNull
        public CoroutineContext minusKey(@NotNull CoroutineContext.Key<?> key) {
            return this.f2443j.minusKey(key);
        }

        @Nullable
        /* renamed from: n */
        public Object mo21603n(@NotNull Continuation<? super Unit> continuation) {
            return this.f2443j.mo21603n(continuation);
        }

        @NotNull
        public CoroutineContext plus(@NotNull CoroutineContext coroutineContext) {
            return this.f2443j.plus(coroutineContext);
        }

        @NotNull
        @C1278i2
        /* renamed from: r */
        public C1324p1 mo21604r(boolean z, boolean z2, @NotNull Function1<? super Throwable, Unit> function1) {
            return this.f2443j.mo21604r(z, z2, function1);
        }

        public boolean start() {
            return this.f2443j.start();
        }

        @NotNull
        @C1278i2
        /* renamed from: u */
        public CancellationException mo21607u() {
            return this.f2443j.mo21607u();
        }

        @Nullable
        /* renamed from: x */
        public Object mo21555x(@NotNull Continuation<? super T> continuation) {
            return this.f2443j.mo21555x(continuation);
        }
    }

    @Metadata(mo21067d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\n¢\u0006\u0002\b\u0005"}, mo21068d2 = {"<anonymous>", "", "T", "it", "", "invoke"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
    /* renamed from: v.c$c */
    public static final class C2087c extends Lambda implements Function1<Throwable, Unit> {

        /* renamed from: j */
        public final /* synthetic */ CancellationTokenSource f2444j;

        /* renamed from: k */
        public final /* synthetic */ C1234c1<T> f2445k;

        /* renamed from: l */
        public final /* synthetic */ TaskCompletionSource<T> f2446l;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C2087c(CancellationTokenSource cancellationTokenSource, C1234c1<? extends T> c1Var, TaskCompletionSource<T> taskCompletionSource) {
            super(1);
            this.f2444j = cancellationTokenSource;
            this.f2445k = c1Var;
            this.f2446l = taskCompletionSource;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((Throwable) obj);
            return Unit.INSTANCE;
        }

        public final void invoke(@Nullable Throwable th) {
            if (th instanceof CancellationException) {
                this.f2444j.cancel();
                return;
            }
            Throwable l = this.f2445k.mo21611l();
            if (l == null) {
                this.f2446l.setResult(this.f2445k.mo21553g());
                return;
            }
            TaskCompletionSource<T> taskCompletionSource = this.f2446l;
            Exception exc = l instanceof Exception ? (Exception) l : null;
            if (exc == null) {
                exc = new RuntimeExecutionException(l);
            }
            taskCompletionSource.setException(exc);
        }
    }

    @Metadata(mo21067d1 = {"\u0000\u0012\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\u0014\u0010\u0003\u001a\u0010\u0012\f\u0012\n \u0005*\u0004\u0018\u0001H\u0002H\u00020\u0004H\n¢\u0006\u0002\b\u0006"}, mo21068d2 = {"<anonymous>", "", "T", "it", "Lcom/google/android/gms/tasks/Task;", "kotlin.jvm.PlatformType", "onComplete"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
    /* renamed from: v.c$d */
    public static final class C2088d<TResult> implements OnCompleteListener {

        /* renamed from: a */
        public final /* synthetic */ C1327q<T> f2447a;

        public C2088d(C1327q<? super T> qVar) {
            this.f2447a = qVar;
        }

        public final void onComplete(@NotNull Task<T> task) {
            T t;
            C1327q<T> qVar;
            Exception exception = task.getException();
            if (exception == null) {
                boolean isCanceled = task.isCanceled();
                qVar = this.f2447a;
                if (isCanceled) {
                    C1327q.C1328a.m651a(qVar, (Throwable) null, 1, (Object) null);
                    return;
                } else {
                    Result.Companion companion = Result.Companion;
                    t = task.getResult();
                }
            } else {
                qVar = this.f2447a;
                Result.Companion companion2 = Result.Companion;
                t = ResultKt.createFailure(exception);
            }
            qVar.resumeWith(Result.m7118constructorimpl(t));
        }
    }

    @Metadata(mo21067d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u0003\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00022\b\u0010\u0003\u001a\u0004\u0018\u00010\u0004H\n¢\u0006\u0002\b\u0005"}, mo21068d2 = {"<anonymous>", "", "T", "it", "", "invoke"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
    /* renamed from: v.c$e */
    public static final class C2089e extends Lambda implements Function1<Throwable, Unit> {

        /* renamed from: j */
        public final /* synthetic */ CancellationTokenSource f2448j;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C2089e(CancellationTokenSource cancellationTokenSource) {
            super(1);
            this.f2448j = cancellationTokenSource;
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((Throwable) obj);
            return Unit.INSTANCE;
        }

        public final void invoke(@Nullable Throwable th) {
            this.f2448j.cancel();
        }
    }

    @NotNull
    /* renamed from: c */
    public static final <T> C1234c1<T> m2990c(@NotNull Task<T> task) {
        return m2992e(task, (CancellationTokenSource) null);
    }

    @NotNull
    @C1236c2
    /* renamed from: d */
    public static final <T> C1234c1<T> m2991d(@NotNull Task<T> task, @NotNull CancellationTokenSource cancellationTokenSource) {
        return m2992e(task, cancellationTokenSource);
    }

    /* renamed from: e */
    public static final <T> C1234c1<T> m2992e(Task<T> task, CancellationTokenSource cancellationTokenSource) {
        C1389z c = C1226b0.m404c((C1309n2) null, 1, (Object) null);
        if (task.isComplete()) {
            Exception exception = task.getException();
            if (exception != null) {
                c.mo21552d(exception);
            } else if (task.isCanceled()) {
                C1309n2.C1310a.m619b(c, (CancellationException) null, 1, (Object) null);
            } else {
                c.mo21551P(task.getResult());
            }
        } else {
            task.addOnCompleteListener((Executor) C2082a.f2440j, (OnCompleteListener<T>) new C2083b(c));
        }
        if (cancellationTokenSource != null) {
            c.mo21593H(new C2085a(cancellationTokenSource));
        }
        return new C2086b(c);
    }

    /* renamed from: f */
    public static final void m2993f(C1389z zVar, Task task) {
        Exception exception = task.getException();
        if (exception != null) {
            zVar.mo21552d(exception);
        } else if (task.isCanceled()) {
            C1309n2.C1310a.m619b(zVar, (CancellationException) null, 1, (Object) null);
        } else {
            zVar.mo21551P(task.getResult());
        }
    }

    @NotNull
    /* renamed from: g */
    public static final <T> Task<T> m2994g(@NotNull C1234c1<? extends T> c1Var) {
        CancellationTokenSource cancellationTokenSource = new CancellationTokenSource();
        TaskCompletionSource taskCompletionSource = new TaskCompletionSource(cancellationTokenSource.getToken());
        c1Var.mo21593H(new C2087c(cancellationTokenSource, c1Var, taskCompletionSource));
        return taskCompletionSource.getTask();
    }

    @Nullable
    @C1236c2
    /* renamed from: h */
    public static final <T> Object m2995h(@NotNull Task<T> task, @NotNull CancellationTokenSource cancellationTokenSource, @NotNull Continuation<? super T> continuation) {
        return m2997j(task, cancellationTokenSource, continuation);
    }

    @Nullable
    /* renamed from: i */
    public static final <T> Object m2996i(@NotNull Task<T> task, @NotNull Continuation<? super T> continuation) {
        return m2997j(task, (CancellationTokenSource) null, continuation);
    }

    /* renamed from: j */
    public static final <T> Object m2997j(Task<T> task, CancellationTokenSource cancellationTokenSource, Continuation<? super T> continuation) {
        if (task.isComplete()) {
            Exception exception = task.getException();
            if (exception != null) {
                throw exception;
            } else if (!task.isCanceled()) {
                return task.getResult();
            } else {
                throw new CancellationException("Task " + task + " was cancelled normally.");
            }
        } else {
            C1333r rVar = new C1333r(IntrinsicsKt__IntrinsicsJvmKt.intercepted(continuation), 1);
            rVar.mo21697E();
            task.addOnCompleteListener((Executor) C2082a.f2440j, (OnCompleteListener<T>) new C2088d(rVar));
            if (cancellationTokenSource != null) {
                rVar.mo21694A(new C2089e(cancellationTokenSource));
            }
            Object x = rVar.mo21736x();
            if (x == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                DebugProbesKt.probeCoroutineSuspended(continuation);
            }
            return x;
        }
    }
}
