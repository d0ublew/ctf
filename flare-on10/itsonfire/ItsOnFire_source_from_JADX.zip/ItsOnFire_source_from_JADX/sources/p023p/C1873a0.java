package p023p;

import kotlin.Metadata;
import org.jetbrains.annotations.NotNull;
import p019l.C1469m;
import p022o.C1682j0;
import p022o.C1780t0;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u001a\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\b\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u000b\n\u0002\b\b\b\u0002\u0018\u00002\b\u0012\u0004\u0012\u00020\u00020\u00012\b\u0012\u0004\u0012\u00020\u00020\u0003B\u000f\u0012\u0006\u0010\n\u001a\u00020\u0002¢\u0006\u0004\b\u000b\u0010\fJ\u000e\u0010\u0006\u001a\u00020\u00052\u0006\u0010\u0004\u001a\u00020\u0002R\u0014\u0010\t\u001a\u00020\u00028VX\u0004¢\u0006\u0006\u001a\u0004\b\u0007\u0010\b¨\u0006\r"}, mo21068d2 = {"Lp/a0;", "Lo/t0;", "", "Lo/j0;", "delta", "", "f0", "e0", "()Ljava/lang/Integer;", "value", "initialValue", "<init>", "(I)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.a0 */
public final class C1873a0 extends C1682j0<Integer> implements C1780t0<Integer> {
    public C1873a0(int i) {
        super(1, Integer.MAX_VALUE, C1469m.DROP_OLDEST);
        mo23097g(Integer.valueOf(i));
    }

    @NotNull
    /* renamed from: e0 */
    public Integer getValue() {
        Integer valueOf;
        synchronized (this) {
            valueOf = Integer.valueOf(((Number) mo23120Q()).intValue());
        }
        return valueOf;
    }

    /* renamed from: f0 */
    public final boolean mo23222f0(int i) {
        boolean g;
        synchronized (this) {
            g = mo23097g(Integer.valueOf(((Number) mo23120Q()).intValue() + i));
        }
        return g;
    }
}
