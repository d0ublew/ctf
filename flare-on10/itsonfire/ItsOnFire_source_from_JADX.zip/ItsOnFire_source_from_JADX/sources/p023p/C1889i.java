package p023p;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p019l.C1469m;
import p022o.C1679i;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u00006\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00000\u0002B3\u0012\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\u000b\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\u0013\u0010\u0014J&\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00000\t2\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0007H\u0014J\u000e\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u000bH\u0016J!\u0010\u0010\u001a\u00020\u000f2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00028\u00000\rH@ø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011\u0002\u0004\n\u0002\b\u0019¨\u0006\u0015"}, mo21068d2 = {"Lp/i;", "T", "Lp/h;", "Lkotlin/coroutines/CoroutineContext;", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "Lp/e;", "j", "Lo/i;", "k", "Lo/j;", "collector", "", "s", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "flow", "<init>", "(Lo/i;Lkotlin/coroutines/CoroutineContext;ILl/m;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.i */
public final class C1889i<T> extends C1887h<T, T> {
    public C1889i(@NotNull C1679i<? extends T> iVar, @NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        super(iVar, coroutineContext, i, mVar);
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1889i(C1679i iVar, CoroutineContext coroutineContext, int i, C1469m mVar, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(iVar, (i2 & 2) != 0 ? EmptyCoroutineContext.INSTANCE : coroutineContext, (i2 & 4) != 0 ? -3 : i, (i2 & 8) != 0 ? C1469m.SUSPEND : mVar);
    }

    @NotNull
    /* renamed from: j */
    public C1879e<T> mo23054j(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        return new C1889i(this.f2026m, coroutineContext, i, mVar);
    }

    @NotNull
    /* renamed from: k */
    public C1679i<T> mo23100k() {
        return this.f2026m;
    }

    @Nullable
    /* renamed from: s */
    public Object mo23237s(@NotNull C1681j<? super T> jVar, @NotNull Continuation<? super Unit> continuation) {
        Object collect = this.f2026m.collect(jVar, continuation);
        return collect == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : Unit.INSTANCE;
    }
}
