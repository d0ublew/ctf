package p023p;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1292l;
import p015j.C1309n2;
import p015j.C1353u0;
import p015j.C1373w0;
import p019l.C1439e0;
import p019l.C1448g0;
import p019l.C1455i0;
import p019l.C1469m;
import p022o.C1679i;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000B\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u001c\n\u0002\u0018\u0002\n\u0002\b\u0006\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002B9\u0012\u0012\u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00130\u0012\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\u0017\u0010\u0018J&\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0007H\u0014J\u0016\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\f2\u0006\u0010\u000b\u001a\u00020\nH\u0016J!\u0010\u0010\u001a\u00020\u000f2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00028\u00000\u000eH@ø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011R \u0010\u0016\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00130\u00128\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0014\u0010\u0015\u0002\u0004\n\u0002\b\u0019¨\u0006\u0019"}, mo21068d2 = {"Lp/k;", "T", "Lp/e;", "Lkotlin/coroutines/CoroutineContext;", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "j", "Lj/u0;", "scope", "Ll/i0;", "n", "Ll/g0;", "", "i", "(Ll/g0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "", "Lo/i;", "m", "Ljava/lang/Iterable;", "flows", "<init>", "(Ljava/lang/Iterable;Lkotlin/coroutines/CoroutineContext;ILl/m;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.k */
public final class C1895k<T> extends C1879e<T> {
    @NotNull

    /* renamed from: m */
    public final Iterable<C1679i<T>> f2049m;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H@"}, mo21068d2 = {"T", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelLimitedFlowMerge$collectTo$2$1", mo22084f = "Merge.kt", mo22085i = {}, mo22086l = {96}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.k$a */
    public static final class C1896a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2050j;

        /* renamed from: k */
        public final /* synthetic */ C1679i<T> f2051k;

        /* renamed from: l */
        public final /* synthetic */ C1932y<T> f2052l;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1896a(C1679i<? extends T> iVar, C1932y<T> yVar, Continuation<? super C1896a> continuation) {
            super(2, continuation);
            this.f2051k = iVar;
            this.f2052l = yVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            return new C1896a(this.f2051k, this.f2052l, continuation);
        }

        @Nullable
        public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1896a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f2050j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                C1679i<T> iVar = this.f2051k;
                C1932y<T> yVar = this.f2052l;
                this.f2050j = 1;
                if (iVar.collect(yVar, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public C1895k(@NotNull Iterable<? extends C1679i<? extends T>> iterable, @NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        super(coroutineContext, i, mVar);
        this.f2049m = iterable;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1895k(Iterable iterable, CoroutineContext coroutineContext, int i, C1469m mVar, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(iterable, (i2 & 2) != 0 ? EmptyCoroutineContext.INSTANCE : coroutineContext, (i2 & 4) != 0 ? -2 : i, (i2 & 8) != 0 ? C1469m.SUSPEND : mVar);
    }

    @Nullable
    /* renamed from: i */
    public Object mo23053i(@NotNull C1448g0<? super T> g0Var, @NotNull Continuation<? super Unit> continuation) {
        C1932y yVar = new C1932y(g0Var);
        for (C1679i<T> aVar : this.f2049m) {
            C1309n2 unused = C1292l.m571f(g0Var, (CoroutineContext) null, (C1373w0) null, new C1896a(aVar, yVar, (Continuation<? super C1896a>) null), 3, (Object) null);
        }
        return Unit.INSTANCE;
    }

    @NotNull
    /* renamed from: j */
    public C1879e<T> mo23054j(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        return new C1895k(this.f2049m, coroutineContext, i, mVar);
    }

    @NotNull
    /* renamed from: n */
    public C1455i0<T> mo23101n(@NotNull C1353u0 u0Var) {
        return C1439e0.m1246d(u0Var, this.f2001j, this.f2002k, mo23230l());
    }
}
