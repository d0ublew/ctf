package p023p;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.ContinuationInterceptor;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p019l.C1448g0;
import p019l.C1469m;
import p022o.C1679i;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000F\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0004\b \u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u00022\b\u0012\u0004\u0012\u00028\u00010\u0003B-\u0012\f\u0010\u0017\u001a\b\u0012\u0004\u0012\u00028\u00000\u0014\u0012\u0006\u0010\u0018\u001a\u00020\u0010\u0012\u0006\u0010\u001a\u001a\u00020\u0019\u0012\u0006\u0010\u001c\u001a\u00020\u001b¢\u0006\u0004\b\u001d\u0010\u001eJ!\u0010\u0007\u001a\u00020\u00062\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004H¤@ø\u0001\u0000¢\u0006\u0004\b\u0007\u0010\bJ!\u0010\u000b\u001a\u00020\u00062\f\u0010\n\u001a\b\u0012\u0004\u0012\u00028\u00010\tH@ø\u0001\u0000¢\u0006\u0004\b\u000b\u0010\fJ!\u0010\r\u001a\u00020\u00062\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00010\u0004H@ø\u0001\u0000¢\u0006\u0004\b\r\u0010\bJ\b\u0010\u000f\u001a\u00020\u000eH\u0016J)\u0010\u0012\u001a\u00020\u00062\f\u0010\u0005\u001a\b\u0012\u0004\u0012\u00028\u00010\u00042\u0006\u0010\u0011\u001a\u00020\u0010H@ø\u0001\u0000¢\u0006\u0004\b\u0012\u0010\u0013R\u001a\u0010\u0017\u001a\b\u0012\u0004\u0012\u00028\u00000\u00148\u0004X\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016\u0002\u0004\n\u0002\b\u0019¨\u0006\u001f"}, mo21068d2 = {"Lp/h;", "S", "T", "Lp/e;", "Lo/j;", "collector", "", "s", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Ll/g0;", "scope", "i", "(Ll/g0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "collect", "", "toString", "Lkotlin/coroutines/CoroutineContext;", "newContext", "r", "(Lo/j;Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lo/i;", "m", "Lo/i;", "flow", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "<init>", "(Lo/i;Lkotlin/coroutines/CoroutineContext;ILl/m;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.h */
public abstract class C1887h<S, T> extends C1879e<T> {
    @NotNull
    @JvmField

    /* renamed from: m */
    public final C1679i<S> f2026m;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0010\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u00012\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00010\u0002H@"}, mo21068d2 = {"S", "T", "Lo/j;", "it", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlowOperator$collectWithContextUndispatched$2", mo22084f = "ChannelFlow.kt", mo22085i = {}, mo22086l = {152}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.h$a */
    public static final class C1888a extends SuspendLambda implements Function2<C1681j<? super T>, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2027j;

        /* renamed from: k */
        public /* synthetic */ Object f2028k;

        /* renamed from: l */
        public final /* synthetic */ C1887h<S, T> f2029l;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1888a(C1887h<S, T> hVar, Continuation<? super C1888a> continuation) {
            super(2, continuation);
            this.f2029l = hVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1888a aVar = new C1888a(this.f2029l, continuation);
            aVar.f2028k = obj;
            return aVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1681j<? super T> jVar, @Nullable Continuation<? super Unit> continuation) {
            return ((C1888a) create(jVar, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f2027j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                C1887h<S, T> hVar = this.f2029l;
                this.f2027j = 1;
                if (hVar.mo23237s((C1681j) this.f2028k, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public C1887h(@NotNull C1679i<? extends S> iVar, @NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        super(coroutineContext, i, mVar);
        this.f2026m = iVar;
    }

    /* renamed from: p */
    public static /* synthetic */ Object m2338p(C1887h hVar, C1681j jVar, Continuation continuation) {
        if (hVar.f2002k == -3) {
            CoroutineContext context = continuation.getContext();
            CoroutineContext plus = context.plus(hVar.f2001j);
            if (Intrinsics.areEqual((Object) plus, (Object) context)) {
                Object s = hVar.mo23237s(jVar, continuation);
                return s == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? s : Unit.INSTANCE;
            }
            ContinuationInterceptor.Key key = ContinuationInterceptor.Key;
            if (Intrinsics.areEqual((Object) plus.get(key), (Object) context.get(key))) {
                Object r = hVar.mo23236r(jVar, plus, continuation);
                return r == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? r : Unit.INSTANCE;
            }
        }
        Object collect = super.collect(jVar, continuation);
        return collect == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : Unit.INSTANCE;
    }

    /* renamed from: q */
    public static /* synthetic */ Object m2339q(C1887h hVar, C1448g0 g0Var, Continuation continuation) {
        Object s = hVar.mo23237s(new C1932y(g0Var), continuation);
        return s == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? s : Unit.INSTANCE;
    }

    @Nullable
    public Object collect(@NotNull C1681j<? super T> jVar, @NotNull Continuation<? super Unit> continuation) {
        return m2338p(this, jVar, continuation);
    }

    @Nullable
    /* renamed from: i */
    public Object mo23053i(@NotNull C1448g0<? super T> g0Var, @NotNull Continuation<? super Unit> continuation) {
        return m2339q(this, g0Var, continuation);
    }

    /* renamed from: r */
    public final Object mo23236r(C1681j<? super T> jVar, CoroutineContext coroutineContext, Continuation<? super Unit> continuation) {
        Object d = C1882f.m2330d(coroutineContext, C1882f.m2331e(jVar, continuation.getContext()), (Object) null, new C1888a(this, (Continuation<? super C1888a>) null), continuation, 4, (Object) null);
        return d == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? d : Unit.INSTANCE;
    }

    @Nullable
    /* renamed from: s */
    public abstract Object mo23237s(@NotNull C1681j<? super T> jVar, @NotNull Continuation<? super Unit> continuation);

    @NotNull
    public String toString() {
        return this.f2026m + " -> " + super.toString();
    }
}
