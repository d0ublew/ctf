package p023p;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.jvm.JvmName;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.InlineMarker;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1309n2;
import p022o.C1679i;
import p022o.C1681j;
import p024q.C1978n0;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u00006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u001a\u0018\u0010\u0004\u001a\u00020\u0003*\u0006\u0012\u0002\b\u00030\u00002\u0006\u0010\u0002\u001a\u00020\u0001H\u0001\u001a\u001b\u0010\u0007\u001a\u0004\u0018\u00010\u0005*\u0004\u0018\u00010\u00052\b\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0010\u001aP\u0010\u0010\u001a\b\u0012\u0004\u0012\u00028\u00000\u000f\"\u0004\b\u0000\u0010\b2/\b\u0005\u0010\u000e\u001a)\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00030\u000b\u0012\u0006\u0012\u0004\u0018\u00010\f0\t¢\u0006\u0002\b\rH\bø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"}, mo21068d2 = {"Lp/v;", "Lkotlin/coroutines/CoroutineContext;", "currentContext", "", "a", "Lj/n2;", "collectJob", "b", "T", "Lkotlin/Function2;", "Lo/j;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "block", "Lo/i;", "c", "(Lkotlin/jvm/functions/Function2;)Lo/i;", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.x */
public final class C1928x {

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0010\u0004\u001a\u00020\u00002\u0006\u0010\u0001\u001a\u00020\u00002\u0006\u0010\u0003\u001a\u00020\u0002H\n¢\u0006\u0004\b\u0004\u0010\u0005"}, mo21068d2 = {"", "count", "Lkotlin/coroutines/CoroutineContext$Element;", "element", "a", "(ILkotlin/coroutines/CoroutineContext$Element;)Ljava/lang/Integer;"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    /* renamed from: p.x$a */
    public static final class C1929a extends Lambda implements Function2<Integer, CoroutineContext.Element, Integer> {

        /* renamed from: j */
        public final /* synthetic */ C1924v<?> f2133j;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1929a(C1924v<?> vVar) {
            super(2);
            this.f2133j = vVar;
        }

        @NotNull
        /* renamed from: a */
        public final Integer mo23256a(int i, @NotNull CoroutineContext.Element element) {
            CoroutineContext.Key key = element.getKey();
            CoroutineContext.Element element2 = this.f2133j.f2126k.get(key);
            if (key != C1309n2.f656b) {
                return Integer.valueOf(element != element2 ? Integer.MIN_VALUE : i + 1);
            }
            C1309n2 n2Var = (C1309n2) element2;
            C1309n2 b = C1928x.m2372b((C1309n2) element, n2Var);
            if (b == n2Var) {
                if (n2Var != null) {
                    i++;
                }
                return Integer.valueOf(i);
            }
            throw new IllegalStateException(("Flow invariant is violated:\n\t\tEmission from another coroutine is detected.\n\t\tChild of " + b + ", expected child of " + n2Var + ".\n\t\tFlowCollector is not thread-safe and concurrent emissions are prohibited.\n\t\tTo mitigate this restriction please use 'channelFlow' builder instead of 'flow'").toString());
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return mo23256a(((Number) obj).intValue(), (CoroutineContext.Element) obj2);
        }
    }

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J!\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H@ø\u0001\u0000¢\u0006\u0004\b\u0005\u0010\u0006\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007"}, mo21068d2 = {"p/x$b", "Lo/i;", "Lo/j;", "collector", "", "collect", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
    /* renamed from: p.x$b */
    public static final class C1930b implements C1679i<T> {

        /* renamed from: j */
        public final /* synthetic */ Function2<C1681j<? super T>, Continuation<? super Unit>, Object> f2134j;

        @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 176)
        /* renamed from: p.x$b$a */
        public static final class C1931a extends ContinuationImpl {

            /* renamed from: j */
            public /* synthetic */ Object f2135j;

            /* renamed from: k */
            public final /* synthetic */ C1930b f2136k;

            /* renamed from: l */
            public int f2137l;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1931a(C1930b bVar, Continuation<? super C1931a> continuation) {
                super(continuation);
                this.f2136k = bVar;
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                this.f2135j = obj;
                this.f2137l |= Integer.MIN_VALUE;
                return this.f2136k.collect((C1681j) null, this);
            }
        }

        public C1930b(Function2<? super C1681j<? super T>, ? super Continuation<? super Unit>, ? extends Object> function2) {
            this.f2134j = function2;
        }

        @Nullable
        public Object collect(@NotNull C1681j<? super T> jVar, @NotNull Continuation<? super Unit> continuation) {
            Object invoke = this.f2134j.invoke(jVar, continuation);
            return invoke == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? invoke : Unit.INSTANCE;
        }

        @Nullable
        /* renamed from: e */
        public Object mo23257e(@NotNull C1681j<? super T> jVar, @NotNull Continuation<? super Unit> continuation) {
            InlineMarker.mark(4);
            new C1931a(this, continuation);
            InlineMarker.mark(5);
            this.f2134j.invoke(jVar, continuation);
            return Unit.INSTANCE;
        }
    }

    @JvmName(name = "checkContext")
    /* renamed from: a */
    public static final void m2371a(@NotNull C1924v<?> vVar, @NotNull CoroutineContext coroutineContext) {
        if (((Number) coroutineContext.fold(0, new C1929a(vVar))).intValue() != vVar.f2127l) {
            throw new IllegalStateException(("Flow invariant is violated:\n\t\tFlow was collected in " + vVar.f2126k + ",\n\t\tbut emission happened in " + coroutineContext + ".\n\t\tPlease refer to 'flow' documentation or use 'flowOn' instead").toString());
        }
    }

    @Nullable
    /* renamed from: b */
    public static final C1309n2 m2372b(@Nullable C1309n2 n2Var, @Nullable C1309n2 n2Var2) {
        while (n2Var != null) {
            if (n2Var == n2Var2 || !(n2Var instanceof C1978n0)) {
                return n2Var;
            }
            n2Var = ((C1978n0) n2Var).mo23365x1();
        }
        return null;
    }

    @NotNull
    @PublishedApi
    /* renamed from: c */
    public static final <T> C1679i<T> m2373c(@NotNull @BuilderInference Function2<? super C1681j<? super T>, ? super Continuation<? super Unit>, ? extends Object> function2) {
        return new C1930b(function2);
    }
}
