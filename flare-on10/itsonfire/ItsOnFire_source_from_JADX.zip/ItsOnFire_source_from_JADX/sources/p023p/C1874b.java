package p023p;

import java.util.Arrays;
import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p022o.C1780t0;
import p023p.C1878d;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0010\b\n\u0000\n\u0002\u0010\u0011\n\u0002\b\u0004\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u000e\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\b \u0018\u0000*\f\b\u0000\u0010\u0002*\u0006\u0012\u0002\b\u00030\u00012\u00060\u0003j\u0002`\u0004B\u0007¢\u0006\u0004\b'\u0010\u0019J\u000f\u0010\u0005\u001a\u00028\u0000H$¢\u0006\u0004\b\u0005\u0010\u0006J\u001f\u0010\n\u001a\n\u0012\u0006\u0012\u0004\u0018\u00018\u00000\t2\u0006\u0010\b\u001a\u00020\u0007H$¢\u0006\u0004\b\n\u0010\u000bJ\u000f\u0010\f\u001a\u00028\u0000H\u0004¢\u0006\u0004\b\f\u0010\u0006J\u0017\u0010\u000f\u001a\u00020\u000e2\u0006\u0010\r\u001a\u00028\u0000H\u0004¢\u0006\u0004\b\u000f\u0010\u0010J\u001d\u0010\u0013\u001a\u00020\u000e2\u0012\u0010\u0012\u001a\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00020\u000e0\u0011H\bR>\u0010\u001a\u001a\f\u0012\u0006\u0012\u0004\u0018\u00018\u0000\u0018\u00010\t2\u0010\u0010\u0014\u001a\f\u0012\u0006\u0012\u0004\u0018\u00018\u0000\u0018\u00010\t8\u0004@BX\u000e¢\u0006\u0012\n\u0004\b\u0005\u0010\u0015\u0012\u0004\b\u0018\u0010\u0019\u001a\u0004\b\u0016\u0010\u0017R$\u0010\u001e\u001a\u00020\u00072\u0006\u0010\u0014\u001a\u00020\u00078\u0004@BX\u000e¢\u0006\f\n\u0004\b\n\u0010\u001b\u001a\u0004\b\u001c\u0010\u001dR\u0016\u0010\u001f\u001a\u00020\u00078\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u0013\u0010\u001bR\u0018\u0010\"\u001a\u0004\u0018\u00010 8\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b\u000f\u0010!R\u0017\u0010&\u001a\b\u0012\u0004\u0012\u00020\u00070#8F¢\u0006\u0006\u001a\u0004\b$\u0010%¨\u0006("}, mo21068d2 = {"Lp/b;", "Lp/d;", "S", "", "Lkotlinx/coroutines/internal/SynchronizedObject;", "j", "()Lp/d;", "", "size", "", "k", "(I)[Lp/d;", "i", "slot", "", "m", "(Lp/d;)V", "Lkotlin/Function1;", "block", "l", "<set-?>", "[Lp/d;", "o", "()[Lp/d;", "getSlots$annotations", "()V", "slots", "I", "n", "()I", "nCollectors", "nextIndex", "Lp/a0;", "Lp/a0;", "_subscriptionCount", "Lo/t0;", "h", "()Lo/t0;", "subscriptionCount", "<init>", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.b */
public abstract class C1874b<S extends C1878d<?>> {
    @Nullable

    /* renamed from: j */
    public S[] f1990j;

    /* renamed from: k */
    public int f1991k;

    /* renamed from: l */
    public int f1992l;
    @Nullable

    /* renamed from: m */
    public C1873a0 f1993m;

    /* renamed from: p */
    public static /* synthetic */ void m2306p() {
    }

    @NotNull
    /* renamed from: h */
    public final C1780t0<Integer> mo23223h() {
        C1873a0 a0Var;
        synchronized (this) {
            a0Var = this.f1993m;
            if (a0Var == null) {
                a0Var = new C1873a0(this.f1991k);
                this.f1993m = a0Var;
            }
        }
        return a0Var;
    }

    @NotNull
    /* renamed from: i */
    public final S mo23224i() {
        S s;
        C1873a0 a0Var;
        synchronized (this) {
            S[] sArr = this.f1990j;
            if (sArr == null) {
                sArr = mo23134k(2);
                this.f1990j = sArr;
            } else if (this.f1991k >= sArr.length) {
                S[] copyOf = Arrays.copyOf(sArr, sArr.length * 2);
                Intrinsics.checkNotNullExpressionValue(copyOf, "copyOf(this, newSize)");
                this.f1990j = (C1878d[]) copyOf;
                sArr = (C1878d[]) copyOf;
            }
            int i = this.f1992l;
            do {
                s = sArr[i];
                if (s == null) {
                    s = mo23133j();
                    sArr[i] = s;
                }
                i++;
                if (i >= sArr.length) {
                    i = 0;
                }
            } while (!s.mo23135a(this));
            this.f1992l = i;
            this.f1991k++;
            a0Var = this.f1993m;
        }
        if (a0Var != null) {
            a0Var.mo23222f0(1);
        }
        return s;
    }

    @NotNull
    /* renamed from: j */
    public abstract S mo23133j();

    @NotNull
    /* renamed from: k */
    public abstract S[] mo23134k(int i);

    /* renamed from: l */
    public final void mo23225l(@NotNull Function1<? super S, Unit> function1) {
        C1878d[] f;
        if (this.f1991k != 0 && (f = this.f1990j) != null) {
            for (C1878d dVar : f) {
                if (dVar != null) {
                    function1.invoke(dVar);
                }
            }
        }
    }

    /* renamed from: m */
    public final void mo23226m(@NotNull S s) {
        C1873a0 a0Var;
        int i;
        Continuation[] b;
        synchronized (this) {
            int i2 = this.f1991k - 1;
            this.f1991k = i2;
            a0Var = this.f1993m;
            if (i2 == 0) {
                this.f1992l = 0;
            }
            b = s.mo23136b(this);
        }
        for (Continuation continuation : b) {
            if (continuation != null) {
                Result.Companion companion = Result.Companion;
                continuation.resumeWith(Result.m7118constructorimpl(Unit.INSTANCE));
            }
        }
        if (a0Var != null) {
            a0Var.mo23222f0(-1);
        }
    }

    /* renamed from: n */
    public final int mo23227n() {
        return this.f1991k;
    }

    @Nullable
    /* renamed from: o */
    public final S[] mo23228o() {
        return this.f1990j;
    }
}
