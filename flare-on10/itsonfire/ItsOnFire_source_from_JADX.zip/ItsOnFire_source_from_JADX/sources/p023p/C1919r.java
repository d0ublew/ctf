package p023p;

import kotlin.Metadata;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import org.jetbrains.annotations.NotNull;
import p015j.C1278i2;
import p019l.C1469m;
import p022o.C1679i;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u001e\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\bg\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002J,\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\b\b\u0002\u0010\u0004\u001a\u00020\u00032\b\b\u0002\u0010\u0006\u001a\u00020\u00052\b\b\u0002\u0010\b\u001a\u00020\u0007H&¨\u0006\n"}, mo21068d2 = {"Lp/r;", "T", "Lo/i;", "Lkotlin/coroutines/CoroutineContext;", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "b", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
@C1278i2
/* renamed from: p.r */
public interface C1919r<T> extends C1679i<T> {

    @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
    /* renamed from: p.r$a */
    public static final class C1920a {
        /* renamed from: a */
        public static /* synthetic */ C1679i m2360a(C1919r rVar, CoroutineContext coroutineContext, int i, C1469m mVar, int i2, Object obj) {
            if (obj == null) {
                if ((i2 & 1) != 0) {
                    coroutineContext = EmptyCoroutineContext.INSTANCE;
                }
                if ((i2 & 2) != 0) {
                    i = -3;
                }
                if ((i2 & 4) != 0) {
                    mVar = C1469m.SUSPEND;
                }
                return rVar.mo23108b(coroutineContext, i, mVar);
            }
            throw new UnsupportedOperationException("Super calls with default arguments not supported in this target, function: fuse");
        }
    }

    @NotNull
    /* renamed from: b */
    C1679i<T> mo23108b(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar);
}
