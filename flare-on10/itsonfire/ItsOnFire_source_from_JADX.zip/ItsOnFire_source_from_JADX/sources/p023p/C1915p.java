package p023p;

import kotlin.BuilderInference;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1353u0;
import p022o.C1679i;
import p022o.C1681j;
import p025r.C2014b;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000.\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\u001aD\u0010\u0007\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u00002)\b\u0001\u0010\u0006\u001a#\b\u0001\u0012\u0004\u0012\u00020\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00040\u0001¢\u0006\u0002\b\u0005H@ø\u0001\u0000¢\u0006\u0004\b\u0007\u0010\b\u001aU\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\f\"\u0004\b\u0000\u0010\u000025\b\u0001\u0010\u0006\u001a/\b\u0001\u0012\u0004\u0012\u00020\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\n\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000b0\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00040\t¢\u0006\u0002\b\u0005H\u0000ø\u0001\u0000¢\u0006\u0004\b\r\u0010\u000e\u0002\u0004\n\u0002\b\u0019¨\u0006\u000f"}, mo21068d2 = {"R", "Lkotlin/Function2;", "Lj/u0;", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "block", "a", "(Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlin/Function3;", "Lo/j;", "", "Lo/i;", "b", "(Lkotlin/jvm/functions/Function3;)Lo/i;", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.p */
public final class C1915p {

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J!\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H@ø\u0001\u0000¢\u0006\u0004\b\u0005\u0010\u0006\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\u0000"}, mo21068d2 = {"p/x$b", "Lo/i;", "Lo/j;", "collector", "", "collect", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
    /* renamed from: p.p$a */
    public static final class C1916a implements C1679i<R> {

        /* renamed from: j */
        public final /* synthetic */ Function3 f2114j;

        public C1916a(Function3 function3) {
            this.f2114j = function3;
        }

        @Nullable
        public Object collect(@NotNull C1681j<? super R> jVar, @NotNull Continuation<? super Unit> continuation) {
            Object a = C1915p.m2355a(new C1917b(this.f2114j, jVar, (Continuation<? super C1917b>) null), continuation);
            return a == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? a : Unit.INSTANCE;
        }
    }

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H@"}, mo21068d2 = {"R", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.FlowCoroutineKt$scopedFlow$1$1", mo22084f = "FlowCoroutine.kt", mo22085i = {}, mo22086l = {51}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.p$b */
    public static final class C1917b extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2115j;

        /* renamed from: k */
        public /* synthetic */ Object f2116k;

        /* renamed from: l */
        public final /* synthetic */ Function3<C1353u0, C1681j<? super R>, Continuation<? super Unit>, Object> f2117l;

        /* renamed from: m */
        public final /* synthetic */ C1681j<R> f2118m;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1917b(Function3<? super C1353u0, ? super C1681j<? super R>, ? super Continuation<? super Unit>, ? extends Object> function3, C1681j<? super R> jVar, Continuation<? super C1917b> continuation) {
            super(2, continuation);
            this.f2117l = function3;
            this.f2118m = jVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1917b bVar = new C1917b(this.f2117l, this.f2118m, continuation);
            bVar.f2116k = obj;
            return bVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1917b) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f2115j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                Function3<C1353u0, C1681j<? super R>, Continuation<? super Unit>, Object> function3 = this.f2117l;
                C1681j<R> jVar = this.f2118m;
                this.f2115j = 1;
                if (function3.invoke((C1353u0) this.f2116k, jVar, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    @Nullable
    /* renamed from: a */
    public static final <R> Object m2355a(@NotNull @BuilderInference Function2<? super C1353u0, ? super Continuation<? super R>, ? extends Object> function2, @NotNull Continuation<? super R> continuation) {
        C1914o oVar = new C1914o(continuation.getContext(), continuation);
        Object f = C2014b.m2730f(oVar, oVar, function2);
        if (f == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
            DebugProbesKt.probeCoroutineSuspended(continuation);
        }
        return f;
    }

    @NotNull
    /* renamed from: b */
    public static final <R> C1679i<R> m2356b(@NotNull @BuilderInference Function3<? super C1353u0, ? super C1681j<? super R>, ? super Continuation<? super Unit>, ? extends Object> function3) {
        return new C1916a(function3);
    }
}
