package p023p;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1309n2;
import p015j.C1353u0;
import p019l.C1439e0;
import p019l.C1448g0;
import p019l.C1455i0;
import p019l.C1469m;
import p022o.C1679i;
import p022o.C1681j;
import p028u.C2076f;
import p028u.C2079h;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000D\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0010\u000e\n\u0000\n\u0002\u0018\u0002\n\u0002\b\b\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002BA\u0012\u0012\u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00140\u0014\u0012\u0006\u0010\u0019\u001a\u00020\u0005\u0012\b\b\u0002\u0010\u0004\u001a\u00020\u0003\u0012\b\b\u0002\u0010\u0006\u001a\u00020\u0005\u0012\b\b\u0002\u0010\b\u001a\u00020\u0007¢\u0006\u0004\b\u001a\u0010\u001bJ&\u0010\t\u001a\b\u0012\u0004\u0012\u00028\u00000\u00022\u0006\u0010\u0004\u001a\u00020\u00032\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u0007H\u0014J\u0016\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00000\f2\u0006\u0010\u000b\u001a\u00020\nH\u0016J!\u0010\u0010\u001a\u00020\u000f2\f\u0010\u000b\u001a\b\u0012\u0004\u0012\u00028\u00000\u000eH@ø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011J\b\u0010\u0013\u001a\u00020\u0012H\u0014R \u0010\u0017\u001a\u000e\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u00140\u00148\u0002X\u0004¢\u0006\u0006\n\u0004\b\u0015\u0010\u0016R\u0014\u0010\u0019\u001a\u00020\u00058\u0002X\u0004¢\u0006\u0006\n\u0004\b\r\u0010\u0018\u0002\u0004\n\u0002\b\u0019¨\u0006\u001c"}, mo21068d2 = {"Lp/g;", "T", "Lp/e;", "Lkotlin/coroutines/CoroutineContext;", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "j", "Lj/u0;", "scope", "Ll/i0;", "n", "Ll/g0;", "", "i", "(Ll/g0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "", "e", "Lo/i;", "m", "Lo/i;", "flow", "I", "concurrency", "<init>", "(Lo/i;ILkotlin/coroutines/CoroutineContext;ILl/m;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.g */
public final class C1883g<T> extends C1879e<T> {
    @NotNull

    /* renamed from: m */
    public final C1679i<C1679i<T>> f2011m;

    /* renamed from: n */
    public final int f2012n;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0010\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u00002\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001H@¢\u0006\u0004\b\u0004\u0010\u0005"}, mo21068d2 = {"T", "Lo/i;", "inner", "", "a", "(Lo/i;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    /* renamed from: p.g$a */
    public static final class C1884a<T> implements C1681j {

        /* renamed from: j */
        public final /* synthetic */ C1309n2 f2013j;

        /* renamed from: k */
        public final /* synthetic */ C2076f f2014k;

        /* renamed from: l */
        public final /* synthetic */ C1448g0<T> f2015l;

        /* renamed from: m */
        public final /* synthetic */ C1932y<T> f2016m;

        @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H@"}, mo21068d2 = {"T", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
        @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlowMerge$collectTo$2$1", mo22084f = "Merge.kt", mo22085i = {}, mo22086l = {69}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
        /* renamed from: p.g$a$a */
        public static final class C1885a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

            /* renamed from: j */
            public int f2017j;

            /* renamed from: k */
            public final /* synthetic */ C1679i<T> f2018k;

            /* renamed from: l */
            public final /* synthetic */ C1932y<T> f2019l;

            /* renamed from: m */
            public final /* synthetic */ C2076f f2020m;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1885a(C1679i<? extends T> iVar, C1932y<T> yVar, C2076f fVar, Continuation<? super C1885a> continuation) {
                super(2, continuation);
                this.f2018k = iVar;
                this.f2019l = yVar;
                this.f2020m = fVar;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                return new C1885a(this.f2018k, this.f2019l, this.f2020m, continuation);
            }

            @Nullable
            public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
                return ((C1885a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.f2017j;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    C1679i<T> iVar = this.f2018k;
                    C1932y<T> yVar = this.f2019l;
                    this.f2017j = 1;
                    if (iVar.collect(yVar, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    try {
                        ResultKt.throwOnFailure(obj);
                    } catch (Throwable th) {
                        this.f2020m.release();
                        throw th;
                    }
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                this.f2020m.release();
                return Unit.INSTANCE;
            }
        }

        @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
        @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlowMerge$collectTo$2", mo22084f = "Merge.kt", mo22085i = {0, 0}, mo22086l = {66}, mo22087m = "emit", mo22088n = {"this", "inner"}, mo22089s = {"L$0", "L$1"})
        /* renamed from: p.g$a$b */
        public static final class C1886b extends ContinuationImpl {

            /* renamed from: j */
            public Object f2021j;

            /* renamed from: k */
            public Object f2022k;

            /* renamed from: l */
            public /* synthetic */ Object f2023l;

            /* renamed from: m */
            public final /* synthetic */ C1884a<T> f2024m;

            /* renamed from: n */
            public int f2025n;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1886b(C1884a<? super T> aVar, Continuation<? super C1886b> continuation) {
                super(continuation);
                this.f2024m = aVar;
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                this.f2023l = obj;
                this.f2025n |= Integer.MIN_VALUE;
                return this.f2024m.emit((C1679i) null, this);
            }
        }

        public C1884a(C1309n2 n2Var, C2076f fVar, C1448g0<? super T> g0Var, C1932y<T> yVar) {
            this.f2013j = n2Var;
            this.f2014k = fVar;
            this.f2015l = g0Var;
            this.f2016m = yVar;
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r6v5, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: o.i<? extends T>} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:12:0x003a  */
        /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
        @org.jetbrains.annotations.Nullable
        /* renamed from: a */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object emit(@org.jetbrains.annotations.NotNull p022o.C1679i<? extends T> r7, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super kotlin.Unit> r8) {
            /*
                r6 = this;
                boolean r0 = r8 instanceof p023p.C1883g.C1884a.C1886b
                if (r0 == 0) goto L_0x0013
                r0 = r8
                p.g$a$b r0 = (p023p.C1883g.C1884a.C1886b) r0
                int r1 = r0.f2025n
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = r1 & r2
                if (r3 == 0) goto L_0x0013
                int r1 = r1 - r2
                r0.f2025n = r1
                goto L_0x0018
            L_0x0013:
                p.g$a$b r0 = new p.g$a$b
                r0.<init>(r6, r8)
            L_0x0018:
                java.lang.Object r8 = r0.f2023l
                java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r2 = r0.f2025n
                r3 = 1
                if (r2 == 0) goto L_0x003a
                if (r2 != r3) goto L_0x0032
                java.lang.Object r6 = r0.f2022k
                r7 = r6
                o.i r7 = (p022o.C1679i) r7
                java.lang.Object r6 = r0.f2021j
                p.g$a r6 = (p023p.C1883g.C1884a) r6
                kotlin.ResultKt.throwOnFailure(r8)
                goto L_0x0053
            L_0x0032:
                java.lang.IllegalStateException r6 = new java.lang.IllegalStateException
                java.lang.String r7 = "call to 'resume' before 'invoke' with coroutine"
                r6.<init>(r7)
                throw r6
            L_0x003a:
                kotlin.ResultKt.throwOnFailure(r8)
                j.n2 r8 = r6.f2013j
                if (r8 == 0) goto L_0x0044
                p015j.C1337r2.m737z(r8)
            L_0x0044:
                u.f r8 = r6.f2014k
                r0.f2021j = r6
                r0.f2022k = r7
                r0.f2025n = r3
                java.lang.Object r8 = r8.mo23574b(r0)
                if (r8 != r1) goto L_0x0053
                return r1
            L_0x0053:
                l.g0<T> r0 = r6.f2015l
                r1 = 0
                r2 = 0
                p.g$a$a r3 = new p.g$a$a
                p.y<T> r8 = r6.f2016m
                u.f r6 = r6.f2014k
                r4 = 0
                r3.<init>(r7, r8, r6, r4)
                r4 = 3
                r5 = 0
                p015j.C1309n2 unused = p015j.C1292l.m571f(r0, r1, r2, r3, r4, r5)
                kotlin.Unit r6 = kotlin.Unit.INSTANCE
                return r6
            */
            throw new UnsupportedOperationException("Method not decompiled: p023p.C1883g.C1884a.emit(o.i, kotlin.coroutines.Continuation):java.lang.Object");
        }
    }

    public C1883g(@NotNull C1679i<? extends C1679i<? extends T>> iVar, int i, @NotNull CoroutineContext coroutineContext, int i2, @NotNull C1469m mVar) {
        super(coroutineContext, i2, mVar);
        this.f2011m = iVar;
        this.f2012n = i;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1883g(C1679i iVar, int i, CoroutineContext coroutineContext, int i2, C1469m mVar, int i3, DefaultConstructorMarker defaultConstructorMarker) {
        this(iVar, i, (i3 & 4) != 0 ? EmptyCoroutineContext.INSTANCE : coroutineContext, (i3 & 8) != 0 ? -2 : i2, (i3 & 16) != 0 ? C1469m.SUSPEND : mVar);
    }

    @NotNull
    /* renamed from: e */
    public String mo23099e() {
        return "concurrency=" + this.f2012n;
    }

    @Nullable
    /* renamed from: i */
    public Object mo23053i(@NotNull C1448g0<? super T> g0Var, @NotNull Continuation<? super Unit> continuation) {
        Object collect = this.f2011m.collect(new C1884a((C1309n2) continuation.getContext().get(C1309n2.f656b), C2079h.m2965b(this.f2012n, 0, 2, (Object) null), g0Var, new C1932y(g0Var)), continuation);
        return collect == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? collect : Unit.INSTANCE;
    }

    @NotNull
    /* renamed from: j */
    public C1879e<T> mo23054j(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        return new C1883g(this.f2011m, this.f2012n, coroutineContext, i, mVar);
    }

    @NotNull
    /* renamed from: n */
    public C1455i0<T> mo23101n(@NotNull C1353u0 u0Var) {
        return C1439e0.m1246d(u0Var, this.f2001j, this.f2002k, mo23230l());
    }
}
