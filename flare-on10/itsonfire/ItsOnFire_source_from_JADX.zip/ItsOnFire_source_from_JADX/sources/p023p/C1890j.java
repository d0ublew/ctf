package p023p;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.Ref;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1309n2;
import p015j.C1353u0;
import p015j.C1362v0;
import p019l.C1469m;
import p022o.C1679i;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000V\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u0001*\u0004\b\u0001\u0010\u00022\u000e\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u00010\u0003Bz\u0012B\u0010\u001a\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\f\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u0012\u0012\b\b\u0013\u0012\u0004\b\b(\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u0011¢\u0006\u0002\b\u0017\u0012\f\u0010\u001c\u001a\b\u0012\u0004\u0012\u00028\u00000\u001b\u0012\b\b\u0002\u0010\u0005\u001a\u00020\u0004\u0012\b\b\u0002\u0010\u0007\u001a\u00020\u0006\u0012\b\b\u0002\u0010\t\u001a\u00020\bø\u0001\u0000¢\u0006\u0004\b\u001d\u0010\u001eJ&\u0010\u000b\u001a\b\u0012\u0004\u0012\u00028\u00010\n2\u0006\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0007\u001a\u00020\u00062\u0006\u0010\t\u001a\u00020\bH\u0014J!\u0010\u000f\u001a\u00020\u000e2\f\u0010\r\u001a\b\u0012\u0004\u0012\u00028\u00010\fH@ø\u0001\u0000¢\u0006\u0004\b\u000f\u0010\u0010RS\u0010\u001a\u001a>\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\f\u0012\u0013\u0012\u00118\u0000¢\u0006\f\b\u0012\u0012\b\b\u0013\u0012\u0004\b\b(\u0014\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000e0\u0015\u0012\u0006\u0012\u0004\u0018\u00010\u00160\u0011¢\u0006\u0002\b\u00178\u0002X\u0004ø\u0001\u0000¢\u0006\u0006\n\u0004\b\u0018\u0010\u0019\u0002\u0004\n\u0002\b\u0019¨\u0006\u001f"}, mo21068d2 = {"Lp/j;", "T", "R", "Lp/h;", "Lkotlin/coroutines/CoroutineContext;", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "Lp/e;", "j", "Lo/j;", "collector", "", "s", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlin/Function3;", "Lkotlin/ParameterName;", "name", "value", "Lkotlin/coroutines/Continuation;", "", "Lkotlin/ExtensionFunctionType;", "n", "Lkotlin/jvm/functions/Function3;", "transform", "Lo/i;", "flow", "<init>", "(Lkotlin/jvm/functions/Function3;Lo/i;Lkotlin/coroutines/CoroutineContext;ILl/m;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.j */
public final class C1890j<T, R> extends C1887h<T, R> {
    @NotNull

    /* renamed from: n */
    public final Function3<C1681j<? super R>, T, Continuation<? super Unit>, Object> f2030n;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001*\u00020\u0002H@"}, mo21068d2 = {"T", "R", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlowTransformLatest$flowCollect$3", mo22084f = "Merge.kt", mo22085i = {}, mo22086l = {27}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.j$a */
    public static final class C1891a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2031j;

        /* renamed from: k */
        public /* synthetic */ Object f2032k;

        /* renamed from: l */
        public final /* synthetic */ C1890j<T, R> f2033l;

        /* renamed from: m */
        public final /* synthetic */ C1681j<R> f2034m;

        @Metadata(mo21067d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u0006\u0010\u0004\u001a\u0002H\u0002H@¢\u0006\u0004\b\u0005\u0010\u0006"}, mo21068d2 = {"<anonymous>", "", "T", "R", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
        /* renamed from: p.j$a$a */
        public static final class C1892a<T> implements C1681j {

            /* renamed from: j */
            public final /* synthetic */ Ref.ObjectRef<C1309n2> f2035j;

            /* renamed from: k */
            public final /* synthetic */ C1353u0 f2036k;

            /* renamed from: l */
            public final /* synthetic */ C1890j<T, R> f2037l;

            /* renamed from: m */
            public final /* synthetic */ C1681j<R> f2038m;

            @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001*\u00020\u0002H@"}, mo21068d2 = {"T", "R", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
            @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlowTransformLatest$flowCollect$3$1$2", mo22084f = "Merge.kt", mo22085i = {}, mo22086l = {34}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
            /* renamed from: p.j$a$a$a */
            public static final class C1893a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

                /* renamed from: j */
                public int f2039j;

                /* renamed from: k */
                public final /* synthetic */ C1890j<T, R> f2040k;

                /* renamed from: l */
                public final /* synthetic */ C1681j<R> f2041l;

                /* renamed from: m */
                public final /* synthetic */ T f2042m;

                /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                public C1893a(C1890j<T, R> jVar, C1681j<? super R> jVar2, T t, Continuation<? super C1893a> continuation) {
                    super(2, continuation);
                    this.f2040k = jVar;
                    this.f2041l = jVar2;
                    this.f2042m = t;
                }

                @NotNull
                public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                    return new C1893a(this.f2040k, this.f2041l, this.f2042m, continuation);
                }

                @Nullable
                public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
                    return ((C1893a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object obj) {
                    Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                    int i = this.f2039j;
                    if (i == 0) {
                        ResultKt.throwOnFailure(obj);
                        Function3 t = this.f2040k.f2030n;
                        C1681j<R> jVar = this.f2041l;
                        T t2 = this.f2042m;
                        this.f2039j = 1;
                        if (t.invoke(jVar, t2, this) == coroutine_suspended) {
                            return coroutine_suspended;
                        }
                    } else if (i == 1) {
                        ResultKt.throwOnFailure(obj);
                    } else {
                        throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                    }
                    return Unit.INSTANCE;
                }
            }

            @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
            @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlowTransformLatest$flowCollect$3$1", mo22084f = "Merge.kt", mo22085i = {0, 0}, mo22086l = {30}, mo22087m = "emit", mo22088n = {"this", "value"}, mo22089s = {"L$0", "L$1"})
            /* renamed from: p.j$a$a$b */
            public static final class C1894b extends ContinuationImpl {

                /* renamed from: j */
                public Object f2043j;

                /* renamed from: k */
                public Object f2044k;

                /* renamed from: l */
                public Object f2045l;

                /* renamed from: m */
                public /* synthetic */ Object f2046m;

                /* renamed from: n */
                public final /* synthetic */ C1892a<T> f2047n;

                /* renamed from: o */
                public int f2048o;

                /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                public C1894b(C1892a<? super T> aVar, Continuation<? super C1894b> continuation) {
                    super(continuation);
                    this.f2047n = aVar;
                }

                @Nullable
                public final Object invokeSuspend(@NotNull Object obj) {
                    this.f2046m = obj;
                    this.f2048o |= Integer.MIN_VALUE;
                    return this.f2047n.emit(null, this);
                }
            }

            public C1892a(Ref.ObjectRef<C1309n2> objectRef, C1353u0 u0Var, C1890j<T, R> jVar, C1681j<? super R> jVar2) {
                this.f2035j = objectRef;
                this.f2036k = u0Var;
                this.f2037l = jVar;
                this.f2038m = jVar2;
            }

            /* JADX WARNING: Removed duplicated region for block: B:12:0x003e  */
            /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
            @org.jetbrains.annotations.Nullable
            /* Code decompiled incorrectly, please refer to instructions dump. */
            public final java.lang.Object emit(T r8, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super kotlin.Unit> r9) {
                /*
                    r7 = this;
                    boolean r0 = r9 instanceof p023p.C1890j.C1891a.C1892a.C1894b
                    if (r0 == 0) goto L_0x0013
                    r0 = r9
                    p.j$a$a$b r0 = (p023p.C1890j.C1891a.C1892a.C1894b) r0
                    int r1 = r0.f2048o
                    r2 = -2147483648(0xffffffff80000000, float:-0.0)
                    r3 = r1 & r2
                    if (r3 == 0) goto L_0x0013
                    int r1 = r1 - r2
                    r0.f2048o = r1
                    goto L_0x0018
                L_0x0013:
                    p.j$a$a$b r0 = new p.j$a$a$b
                    r0.<init>(r7, r9)
                L_0x0018:
                    java.lang.Object r9 = r0.f2046m
                    java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                    int r2 = r0.f2048o
                    r3 = 1
                    if (r2 == 0) goto L_0x003e
                    if (r2 != r3) goto L_0x0036
                    java.lang.Object r7 = r0.f2045l
                    j.n2 r7 = (p015j.C1309n2) r7
                    java.lang.Object r7 = r0.f2044k
                    java.lang.Object r8 = r0.f2043j
                    p.j$a$a r8 = (p023p.C1890j.C1891a.C1892a) r8
                    kotlin.ResultKt.throwOnFailure(r9)
                    r6 = r8
                    r8 = r7
                    r7 = r6
                    goto L_0x0060
                L_0x0036:
                    java.lang.IllegalStateException r7 = new java.lang.IllegalStateException
                    java.lang.String r8 = "call to 'resume' before 'invoke' with coroutine"
                    r7.<init>(r8)
                    throw r7
                L_0x003e:
                    kotlin.ResultKt.throwOnFailure(r9)
                    kotlin.jvm.internal.Ref$ObjectRef<j.n2> r9 = r7.f2035j
                    T r9 = r9.element
                    j.n2 r9 = (p015j.C1309n2) r9
                    if (r9 == 0) goto L_0x0060
                    p.l r2 = new p.l
                    r2.<init>()
                    r9.cancel(r2)
                    r0.f2043j = r7
                    r0.f2044k = r8
                    r0.f2045l = r9
                    r0.f2048o = r3
                    java.lang.Object r9 = r9.mo21603n(r0)
                    if (r9 != r1) goto L_0x0060
                    return r1
                L_0x0060:
                    kotlin.jvm.internal.Ref$ObjectRef<j.n2> r9 = r7.f2035j
                    j.u0 r0 = r7.f2036k
                    r1 = 0
                    j.w0 r2 = p015j.C1373w0.UNDISPATCHED
                    p.j$a$a$a r3 = new p.j$a$a$a
                    p.j<T, R> r4 = r7.f2037l
                    o.j<R> r7 = r7.f2038m
                    r5 = 0
                    r3.<init>(r4, r7, r8, r5)
                    r4 = 1
                    j.n2 r7 = p015j.C1292l.m571f(r0, r1, r2, r3, r4, r5)
                    r9.element = r7
                    kotlin.Unit r7 = kotlin.Unit.INSTANCE
                    return r7
                */
                throw new UnsupportedOperationException("Method not decompiled: p023p.C1890j.C1891a.C1892a.emit(java.lang.Object, kotlin.coroutines.Continuation):java.lang.Object");
            }
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1891a(C1890j<T, R> jVar, C1681j<? super R> jVar2, Continuation<? super C1891a> continuation) {
            super(2, continuation);
            this.f2033l = jVar;
            this.f2034m = jVar2;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1891a aVar = new C1891a(this.f2033l, this.f2034m, continuation);
            aVar.f2032k = obj;
            return aVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1891a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f2031j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                Ref.ObjectRef objectRef = new Ref.ObjectRef();
                C1890j<T, R> jVar = this.f2033l;
                C1679i<S> iVar = jVar.f2026m;
                C1892a aVar = new C1892a(objectRef, (C1353u0) this.f2032k, jVar, this.f2034m);
                this.f2031j = 1;
                if (iVar.collect(aVar, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public C1890j(@NotNull Function3<? super C1681j<? super R>, ? super T, ? super Continuation<? super Unit>, ? extends Object> function3, @NotNull C1679i<? extends T> iVar, @NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        super(iVar, coroutineContext, i, mVar);
        this.f2030n = function3;
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ C1890j(Function3 function3, C1679i iVar, CoroutineContext coroutineContext, int i, C1469m mVar, int i2, DefaultConstructorMarker defaultConstructorMarker) {
        this(function3, iVar, (i2 & 4) != 0 ? EmptyCoroutineContext.INSTANCE : coroutineContext, (i2 & 8) != 0 ? -2 : i, (i2 & 16) != 0 ? C1469m.SUSPEND : mVar);
    }

    @NotNull
    /* renamed from: j */
    public C1879e<R> mo23054j(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        return new C1890j(this.f2030n, this.f2026m, coroutineContext, i, mVar);
    }

    @Nullable
    /* renamed from: s */
    public Object mo23237s(@NotNull C1681j<? super R> jVar, @NotNull Continuation<? super Unit> continuation) {
        Object g = C1362v0.m861g(new C1891a(this, jVar, (Continuation<? super C1891a>) null), continuation);
        return g == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? g : Unit.INSTANCE;
    }
}
