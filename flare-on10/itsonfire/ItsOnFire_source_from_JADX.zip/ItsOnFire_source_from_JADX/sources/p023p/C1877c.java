package p023p;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.jvm.JvmField;
import org.jetbrains.annotations.NotNull;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0010\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\"(\u0010\u0007\u001a\u0010\u0012\f\u0012\n\u0012\u0004\u0012\u00020\u0002\u0018\u00010\u00010\u00008\u0000X\u0004¢\u0006\f\n\u0004\b\u0003\u0010\u0004\u0012\u0004\b\u0005\u0010\u0006¨\u0006\b"}, mo21068d2 = {"", "Lkotlin/coroutines/Continuation;", "", "a", "[Lkotlin/coroutines/Continuation;", "getEMPTY_RESUMES$annotations", "()V", "EMPTY_RESUMES", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.c */
public final class C1877c {
    @NotNull
    @JvmField

    /* renamed from: a */
    public static final Continuation<Unit>[] f2000a = new Continuation[0];

    /* renamed from: a */
    public static /* synthetic */ void m2315a() {
    }
}
