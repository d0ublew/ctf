package p023p;

import kotlin.Metadata;
import kotlin.jvm.JvmField;
import org.jetbrains.annotations.NotNull;
import p024q.C1986r0;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\b\n\u0002\u0018\u0002\n\u0002\b\f\"\u001a\u0010\u0005\u001a\u00020\u00008\u0000X\u0004¢\u0006\f\n\u0004\b\u0001\u0010\u0002\u0012\u0004\b\u0003\u0010\u0004\"\u001a\u0010\b\u001a\u00020\u00008\u0000X\u0004¢\u0006\f\n\u0004\b\u0006\u0010\u0002\u0012\u0004\b\u0007\u0010\u0004\"\u001a\u0010\u000b\u001a\u00020\u00008\u0000X\u0004¢\u0006\f\n\u0004\b\t\u0010\u0002\u0012\u0004\b\n\u0010\u0004¨\u0006\f"}, mo21068d2 = {"Lq/r0;", "a", "Lq/r0;", "getNULL$annotations", "()V", "NULL", "b", "getUNINITIALIZED$annotations", "UNINITIALIZED", "c", "getDONE$annotations", "DONE", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.u */
public final class C1923u {
    @NotNull
    @JvmField

    /* renamed from: a */
    public static final C1986r0 f2122a = new C1986r0("NULL");
    @NotNull
    @JvmField

    /* renamed from: b */
    public static final C1986r0 f2123b = new C1986r0("UNINITIALIZED");
    @NotNull
    @JvmField

    /* renamed from: c */
    public static final C1986r0 f2124c = new C1986r0("DONE");

    /* renamed from: a */
    public static /* synthetic */ void m2361a() {
    }

    /* renamed from: b */
    public static /* synthetic */ void m2362b() {
    }

    /* renamed from: c */
    public static /* synthetic */ void m2363c() {
    }
}
