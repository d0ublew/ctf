package p023p;

import kotlin.Metadata;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.SuspendFunction;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.FunctionReferenceImpl;
import kotlin.jvm.internal.TypeIntrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\b\u0006\"D\u0010\t\u001a,\u0012\f\u0012\n\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u0001\u0012\u0006\u0012\u0004\u0018\u00010\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0003\u0012\u0006\u0012\u0004\u0018\u00010\u00020\u00008\u0002X\u0004¢\u0006\f\n\u0004\b\u0005\u0010\u0006\u0012\u0004\b\u0007\u0010\b¨\u0006\n"}, mo21068d2 = {"Lkotlin/Function3;", "Lo/j;", "", "Lkotlin/coroutines/Continuation;", "", "a", "Lkotlin/jvm/functions/Function3;", "getEmitFun$annotations", "()V", "emitFun", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.w */
public final class C1926w {
    @NotNull

    /* renamed from: a */
    public static final Function3<C1681j<Object>, Object, Continuation<? super Unit>, Object> f2131a = ((Function3) TypeIntrinsics.beforeCheckcastToFunctionOfArity(C1927a.f2132j, 3));

    @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
    /* renamed from: p.w$a */
    public /* synthetic */ class C1927a extends FunctionReferenceImpl implements Function3<C1681j<? super Object>, Object, Continuation<? super Unit>, Object>, SuspendFunction {

        /* renamed from: j */
        public static final C1927a f2132j = new C1927a();

        public C1927a() {
            super(3, C1681j.class, "emit", "emit(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", 0);
        }

        @Nullable
        /* renamed from: a */
        public final Object invoke(@NotNull C1681j<Object> jVar, @Nullable Object obj, @NotNull Continuation<? super Unit> continuation) {
            return jVar.emit(obj, continuation);
        }
    }

    /* renamed from: b */
    public static /* synthetic */ void m2369b() {
    }
}
