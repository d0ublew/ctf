package p023p;

import kotlin.Metadata;
import kotlin.Result;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.CoroutineStackFrame;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1337r2;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000L\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\b\u0004\n\u0002\u0018\u0002\n\u0002\b\u0006\n\u0002\u0010\b\n\u0002\b\u0011\b\u0000\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u00022\u00020\u00032\u00020\u0004B\u001d\u0012\f\u0010\u001e\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\u0006\u0010 \u001a\u00020\u0015¢\u0006\u0004\b0\u00101J\n\u0010\u0006\u001a\u0004\u0018\u00010\u0005H\u0016J\"\u0010\n\u001a\u00020\b2\u000e\u0010\t\u001a\n\u0012\u0006\u0012\u0004\u0018\u00010\b0\u0007H\u0016ø\u0001\u0000¢\u0006\u0004\b\n\u0010\u000bJ\b\u0010\r\u001a\u00020\fH\u0016J\u001b\u0010\u000f\u001a\u00020\f2\u0006\u0010\u000e\u001a\u00028\u0000H@ø\u0001\u0000¢\u0006\u0004\b\u000f\u0010\u0010J'\u0010\u0013\u001a\u0004\u0018\u00010\b2\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00020\f0\u00112\u0006\u0010\u000e\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0013\u0010\u0014J)\u0010\u0018\u001a\u00020\f2\u0006\u0010\u0016\u001a\u00020\u00152\b\u0010\u0017\u001a\u0004\u0018\u00010\u00152\u0006\u0010\u000e\u001a\u00028\u0000H\u0002¢\u0006\u0004\b\u0018\u0010\u0019J\u001a\u0010\u001c\u001a\u00020\f2\u0006\u0010\u001b\u001a\u00020\u001a2\b\u0010\u000e\u001a\u0004\u0018\u00010\bH\u0002R\u001a\u0010\u001e\u001a\b\u0012\u0004\u0012\u00028\u00000\u00028\u0000X\u0004¢\u0006\u0006\n\u0004\b\u0013\u0010\u001dR\u0014\u0010 \u001a\u00020\u00158\u0000X\u0004¢\u0006\u0006\n\u0004\b\u001c\u0010\u001fR\u0014\u0010$\u001a\u00020!8\u0000X\u0004¢\u0006\u0006\n\u0004\b\"\u0010#R\u0018\u0010&\u001a\u0004\u0018\u00010\u00158\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b%\u0010\u001fR\u001e\u0010)\u001a\n\u0012\u0004\u0012\u00020\f\u0018\u00010\u00118\u0002@\u0002X\u000e¢\u0006\u0006\n\u0004\b'\u0010(R\u0016\u0010,\u001a\u0004\u0018\u00010\u00048VX\u0004¢\u0006\u0006\u001a\u0004\b*\u0010+R\u0014\u0010/\u001a\u00020\u00158VX\u0004¢\u0006\u0006\u001a\u0004\b-\u0010.\u0002\u0004\n\u0002\b\u0019¨\u00062"}, mo21068d2 = {"Lp/v;", "T", "Lo/j;", "Lkotlin/coroutines/jvm/internal/ContinuationImpl;", "Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "Ljava/lang/StackTraceElement;", "getStackTraceElement", "Lkotlin/Result;", "", "result", "invokeSuspend", "(Ljava/lang/Object;)Ljava/lang/Object;", "", "releaseIntercepted", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlin/coroutines/Continuation;", "uCont", "j", "(Lkotlin/coroutines/Continuation;Ljava/lang/Object;)Ljava/lang/Object;", "Lkotlin/coroutines/CoroutineContext;", "currentContext", "previousContext", "i", "(Lkotlin/coroutines/CoroutineContext;Lkotlin/coroutines/CoroutineContext;Ljava/lang/Object;)V", "Lp/n;", "exception", "k", "Lo/j;", "collector", "Lkotlin/coroutines/CoroutineContext;", "collectContext", "", "l", "I", "collectContextSize", "m", "lastEmissionContext", "n", "Lkotlin/coroutines/Continuation;", "completion", "getCallerFrame", "()Lkotlin/coroutines/jvm/internal/CoroutineStackFrame;", "callerFrame", "getContext", "()Lkotlin/coroutines/CoroutineContext;", "context", "<init>", "(Lo/j;Lkotlin/coroutines/CoroutineContext;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.v */
public final class C1924v<T> extends ContinuationImpl implements C1681j<T>, CoroutineStackFrame {
    @NotNull
    @JvmField

    /* renamed from: j */
    public final C1681j<T> f2125j;
    @NotNull
    @JvmField

    /* renamed from: k */
    public final CoroutineContext f2126k;
    @JvmField

    /* renamed from: l */
    public final int f2127l;
    @Nullable

    /* renamed from: m */
    public CoroutineContext f2128m;
    @Nullable

    /* renamed from: n */
    public Continuation<? super Unit> f2129n;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\u0010\u0005\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0002\u001a\u00020\u00012\u0006\u0010\u0004\u001a\u00020\u0003H\n¢\u0006\u0004\b\u0005\u0010\u0006"}, mo21068d2 = {"T", "", "count", "Lkotlin/coroutines/CoroutineContext$Element;", "<anonymous parameter 1>", "a", "(ILkotlin/coroutines/CoroutineContext$Element;)Ljava/lang/Integer;"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    /* renamed from: p.v$a */
    public static final class C1925a extends Lambda implements Function2<Integer, CoroutineContext.Element, Integer> {

        /* renamed from: j */
        public static final C1925a f2130j = new C1925a();

        public C1925a() {
            super(2);
        }

        @NotNull
        /* renamed from: a */
        public final Integer mo23254a(int i, @NotNull CoroutineContext.Element element) {
            return Integer.valueOf(i + 1);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2) {
            return mo23254a(((Number) obj).intValue(), (CoroutineContext.Element) obj2);
        }
    }

    public C1924v(@NotNull C1681j<? super T> jVar, @NotNull CoroutineContext coroutineContext) {
        super(C1921s.f2119j, EmptyCoroutineContext.INSTANCE);
        this.f2125j = jVar;
        this.f2126k = coroutineContext;
        this.f2127l = ((Number) coroutineContext.fold(0, C1925a.f2130j)).intValue();
    }

    @Nullable
    public Object emit(T t, @NotNull Continuation<? super Unit> continuation) {
        try {
            Object j = mo23252j(continuation, t);
            if (j == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                DebugProbesKt.probeCoroutineSuspended(continuation);
            }
            return j == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? j : Unit.INSTANCE;
        } catch (Throwable th) {
            this.f2128m = new C1913n(th, continuation.getContext());
            throw th;
        }
    }

    @Nullable
    public CoroutineStackFrame getCallerFrame() {
        Continuation<? super Unit> continuation = this.f2129n;
        if (continuation instanceof CoroutineStackFrame) {
            return (CoroutineStackFrame) continuation;
        }
        return null;
    }

    @NotNull
    public CoroutineContext getContext() {
        CoroutineContext coroutineContext = this.f2128m;
        return coroutineContext == null ? EmptyCoroutineContext.INSTANCE : coroutineContext;
    }

    @Nullable
    public StackTraceElement getStackTraceElement() {
        return null;
    }

    /* renamed from: i */
    public final void mo23251i(CoroutineContext coroutineContext, CoroutineContext coroutineContext2, T t) {
        if (coroutineContext2 instanceof C1913n) {
            mo23253k((C1913n) coroutineContext2, t);
        }
        C1928x.m2371a(this, coroutineContext);
    }

    @NotNull
    public Object invokeSuspend(@NotNull Object obj) {
        Throwable r0 = Result.m7121exceptionOrNullimpl(obj);
        if (r0 != null) {
            this.f2128m = new C1913n(r0, getContext());
        }
        Continuation<? super Unit> continuation = this.f2129n;
        if (continuation != null) {
            continuation.resumeWith(obj);
        }
        return IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
    }

    /* renamed from: j */
    public final Object mo23252j(Continuation<? super Unit> continuation, T t) {
        CoroutineContext context = continuation.getContext();
        C1337r2.m709A(context);
        CoroutineContext coroutineContext = this.f2128m;
        if (coroutineContext != context) {
            mo23251i(context, coroutineContext, t);
            this.f2128m = context;
        }
        this.f2129n = continuation;
        Object invoke = C1926w.f2131a.invoke(this.f2125j, t, this);
        if (!Intrinsics.areEqual(invoke, IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED())) {
            this.f2129n = null;
        }
        return invoke;
    }

    /* renamed from: k */
    public final void mo23253k(C1913n nVar, Object obj) {
        throw new IllegalStateException(StringsKt__IndentKt.trimIndent("\n            Flow exception transparency is violated:\n                Previous 'emit' call has thrown exception " + nVar.f2112j + ", but then emission attempt of value '" + obj + "' has been detected.\n                Emissions from 'catch' blocks are prohibited in order to avoid unspecified behaviour, 'Flow.catch' operator can be used instead.\n                For a more detailed explanation, please refer to Flow documentation.\n            ").toString());
    }

    public void releaseIntercepted() {
        super.releaseIntercepted();
    }
}
