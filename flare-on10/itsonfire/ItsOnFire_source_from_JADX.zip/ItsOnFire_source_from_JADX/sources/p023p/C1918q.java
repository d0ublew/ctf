package p023p;

import kotlin.Metadata;
import kotlin.PublishedApi;
import org.jetbrains.annotations.NotNull;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0018\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\n\u0002\u0010\b\n\u0002\b\u0003\u001a\u0018\u0010\u0004\u001a\u00020\u0003*\u00020\u00002\n\u0010\u0002\u001a\u0006\u0012\u0002\b\u00030\u0001H\u0000\u001a\u0011\u0010\u0007\u001a\u00020\u00052\u0006\u0010\u0006\u001a\u00020\u0005H\b¨\u0006\b"}, mo21068d2 = {"Lp/a;", "Lo/j;", "owner", "", "b", "", "index", "a", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.q */
public final class C1918q {
    @PublishedApi
    /* renamed from: a */
    public static final int m2357a(int i) {
        if (i >= 0) {
            return i;
        }
        throw new ArithmeticException("Index overflow has happened");
    }

    /* renamed from: b */
    public static final void m2358b(@NotNull C1872a aVar, @NotNull C1681j<?> jVar) {
        if (aVar.f1989j != jVar) {
            throw aVar;
        }
    }
}
