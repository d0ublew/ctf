package p023p;

import java.util.ArrayList;
import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.EmptyCoroutineContext;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.JvmField;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.Intrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1278i2;
import p015j.C1353u0;
import p015j.C1362v0;
import p015j.C1373w0;
import p015j.C1391z0;
import p019l.C1439e0;
import p019l.C1448g0;
import p019l.C1455i0;
import p019l.C1469m;
import p022o.C1679i;
import p022o.C1681j;
import p022o.C1686k;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\\\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\b\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u000e\n\u0002\b\u0006\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\b\b\b'\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002B\u001f\u0012\u0006\u0010\u0006\u001a\u00020\u0005\u0012\u0006\u0010\b\u001a\u00020\u0007\u0012\u0006\u0010\n\u001a\u00020\t¢\u0006\u0004\b(\u0010)J\u0010\u0010\u0004\u001a\n\u0012\u0004\u0012\u00028\u0000\u0018\u00010\u0003H\u0016J&\u0010\u000b\u001a\b\u0012\u0004\u0012\u00028\u00000\u00032\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH\u0016J&\u0010\f\u001a\b\u0012\u0004\u0012\u00028\u00000\u00002\u0006\u0010\u0006\u001a\u00020\u00052\u0006\u0010\b\u001a\u00020\u00072\u0006\u0010\n\u001a\u00020\tH$J!\u0010\u0010\u001a\u00020\u000f2\f\u0010\u000e\u001a\b\u0012\u0004\u0012\u00028\u00000\rH¤@ø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011J\u0016\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u00132\u0006\u0010\u000e\u001a\u00020\u0012H\u0016J!\u0010\u0017\u001a\u00020\u000f2\f\u0010\u0016\u001a\b\u0012\u0004\u0012\u00028\u00000\u0015H@ø\u0001\u0000¢\u0006\u0004\b\u0017\u0010\u0018J\n\u0010\u001a\u001a\u0004\u0018\u00010\u0019H\u0014J\b\u0010\u001b\u001a\u00020\u0019H\u0016R\u0014\u0010\u0006\u001a\u00020\u00058\u0006X\u0004¢\u0006\u0006\n\u0004\b\f\u0010\u001cR\u0014\u0010\b\u001a\u00020\u00078\u0006X\u0004¢\u0006\u0006\n\u0004\b\u0004\u0010\u001dR\u0014\u0010\n\u001a\u00020\t8\u0006X\u0004¢\u0006\u0006\n\u0004\b\u001e\u0010\u001fR9\u0010$\u001a$\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\r\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u000f0!\u0012\u0006\u0012\u0004\u0018\u00010\"0 8@X\u0004ø\u0001\u0000¢\u0006\u0006\u001a\u0004\b\u001e\u0010#R\u0014\u0010'\u001a\u00020\u00078@X\u0004¢\u0006\u0006\u001a\u0004\b%\u0010&\u0002\u0004\n\u0002\b\u0019¨\u0006*"}, mo21068d2 = {"Lp/e;", "T", "Lp/r;", "Lo/i;", "k", "Lkotlin/coroutines/CoroutineContext;", "context", "", "capacity", "Ll/m;", "onBufferOverflow", "b", "j", "Ll/g0;", "scope", "", "i", "(Ll/g0;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lj/u0;", "Ll/i0;", "n", "Lo/j;", "collector", "collect", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "", "e", "toString", "Lkotlin/coroutines/CoroutineContext;", "I", "l", "Ll/m;", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "", "()Lkotlin/jvm/functions/Function2;", "collectToFun", "m", "()I", "produceCapacity", "<init>", "(Lkotlin/coroutines/CoroutineContext;ILl/m;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
@C1278i2
/* renamed from: p.e */
public abstract class C1879e<T> implements C1919r<T> {
    @NotNull
    @JvmField

    /* renamed from: j */
    public final CoroutineContext f2001j;
    @JvmField

    /* renamed from: k */
    public final int f2002k;
    @NotNull
    @JvmField

    /* renamed from: l */
    public final C1469m f2003l;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\f\n\u0000\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u0000*\u00020\u0001H@"}, mo21068d2 = {"T", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlow$collect$2", mo22084f = "ChannelFlow.kt", mo22085i = {}, mo22086l = {123}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.e$a */
    public static final class C1880a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2004j;

        /* renamed from: k */
        public /* synthetic */ Object f2005k;

        /* renamed from: l */
        public final /* synthetic */ C1681j<T> f2006l;

        /* renamed from: m */
        public final /* synthetic */ C1879e<T> f2007m;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1880a(C1681j<? super T> jVar, C1879e<T> eVar, Continuation<? super C1880a> continuation) {
            super(2, continuation);
            this.f2006l = jVar;
            this.f2007m = eVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1880a aVar = new C1880a(this.f2006l, this.f2007m, continuation);
            aVar.f2005k = obj;
            return aVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1880a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f2004j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                C1681j<T> jVar = this.f2006l;
                C1455i0<T> n = this.f2007m.mo23101n((C1353u0) this.f2005k);
                this.f2004j = 1;
                if (C1686k.m2018l0(jVar, n, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u00002\f\u0010\u0002\u001a\b\u0012\u0004\u0012\u00028\u00000\u0001H@"}, mo21068d2 = {"T", "Ll/g0;", "it", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.ChannelFlow$collectToFun$1", mo22084f = "ChannelFlow.kt", mo22085i = {}, mo22086l = {60}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.e$b */
    public static final class C1881b extends SuspendLambda implements Function2<C1448g0<? super T>, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2008j;

        /* renamed from: k */
        public /* synthetic */ Object f2009k;

        /* renamed from: l */
        public final /* synthetic */ C1879e<T> f2010l;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1881b(C1879e<T> eVar, Continuation<? super C1881b> continuation) {
            super(2, continuation);
            this.f2010l = eVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1881b bVar = new C1881b(this.f2010l, continuation);
            bVar.f2009k = obj;
            return bVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1448g0<? super T> g0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1881b) create(g0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f2008j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                C1879e<T> eVar = this.f2010l;
                this.f2008j = 1;
                if (eVar.mo23053i((C1448g0) this.f2009k, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public C1879e(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        this.f2001j = coroutineContext;
        this.f2002k = i;
        this.f2003l = mVar;
    }

    /* renamed from: f */
    public static /* synthetic */ Object m2318f(C1879e eVar, C1681j jVar, Continuation continuation) {
        Object g = C1362v0.m861g(new C1880a(jVar, eVar, (Continuation<? super C1880a>) null), continuation);
        return g == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? g : Unit.INSTANCE;
    }

    @NotNull
    /* renamed from: b */
    public C1679i<T> mo23108b(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar) {
        CoroutineContext plus = coroutineContext.plus(this.f2001j);
        if (mVar == C1469m.SUSPEND) {
            int i2 = this.f2002k;
            if (i2 != -3) {
                if (i != -3) {
                    if (i2 != -2) {
                        if (i != -2 && (i2 = i2 + i) < 0) {
                            i = Integer.MAX_VALUE;
                        }
                    }
                }
                i = i2;
            }
            mVar = this.f2003l;
        }
        return (Intrinsics.areEqual((Object) plus, (Object) this.f2001j) && i == this.f2002k && mVar == this.f2003l) ? this : mo23054j(plus, i, mVar);
    }

    @Nullable
    public Object collect(@NotNull C1681j<? super T> jVar, @NotNull Continuation<? super Unit> continuation) {
        return m2318f(this, jVar, continuation);
    }

    @Nullable
    /* renamed from: e */
    public String mo23099e() {
        return null;
    }

    @Nullable
    /* renamed from: i */
    public abstract Object mo23053i(@NotNull C1448g0<? super T> g0Var, @NotNull Continuation<? super Unit> continuation);

    @NotNull
    /* renamed from: j */
    public abstract C1879e<T> mo23054j(@NotNull CoroutineContext coroutineContext, int i, @NotNull C1469m mVar);

    @Nullable
    /* renamed from: k */
    public C1679i<T> mo23100k() {
        return null;
    }

    @NotNull
    /* renamed from: l */
    public final Function2<C1448g0<? super T>, Continuation<? super Unit>, Object> mo23230l() {
        return new C1881b(this, (Continuation<? super C1881b>) null);
    }

    /* renamed from: m */
    public final int mo23231m() {
        int i = this.f2002k;
        if (i == -3) {
            return -2;
        }
        return i;
    }

    @NotNull
    /* renamed from: n */
    public C1455i0<T> mo23101n(@NotNull C1353u0 u0Var) {
        return C1439e0.m1250h(u0Var, this.f2001j, mo23231m(), this.f2003l, C1373w0.ATOMIC, (Function1) null, mo23230l(), 16, (Object) null);
    }

    @NotNull
    public String toString() {
        ArrayList arrayList = new ArrayList(4);
        String e = mo23099e();
        if (e != null) {
            arrayList.add(e);
        }
        if (this.f2001j != EmptyCoroutineContext.INSTANCE) {
            arrayList.add("context=" + this.f2001j);
        }
        if (this.f2002k != -3) {
            arrayList.add("capacity=" + this.f2002k);
        }
        if (this.f2003l != C1469m.SUSPEND) {
            arrayList.add("onBufferOverflow=" + this.f2003l);
        }
        return C1391z0.m1042a(this) + '[' + CollectionsKt___CollectionsKt.joinToString$default(arrayList, ", ", (CharSequence) null, (CharSequence) null, 0, (CharSequence) null, (Function1) null, 62, (Object) null) + ']';
    }
}
