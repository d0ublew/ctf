package p023p;

import kotlin.Metadata;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p022o.C1681j;
import p024q.C1996w0;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u00000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\b\u0003\n\u0002\u0010\u0000\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0007\b\u0002\u0018\u0000*\u0004\b\u0000\u0010\u00012\b\u0012\u0004\u0012\u00028\u00000\u0002B\u001d\u0012\f\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\u0006\u0010\n\u001a\u00020\u0007¢\u0006\u0004\b\u0015\u0010\u0016J\u001b\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00028\u0000H@ø\u0001\u0000¢\u0006\u0004\b\u0005\u0010\u0006R\u0014\u0010\n\u001a\u00020\u00078\u0002X\u0004¢\u0006\u0006\n\u0004\b\b\u0010\tR\u0014\u0010\u000e\u001a\u00020\u000b8\u0002X\u0004¢\u0006\u0006\n\u0004\b\f\u0010\rR3\u0010\u0013\u001a\u001e\b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\n\u0012\b\u0012\u0004\u0012\u00020\u00040\u0010\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u000f8\u0002X\u0004ø\u0001\u0000¢\u0006\u0006\n\u0004\b\u0011\u0010\u0012\u0002\u0004\n\u0002\b\u0019¨\u0006\u0017"}, mo21068d2 = {"Lp/b0;", "T", "Lo/j;", "value", "", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "Lkotlin/coroutines/CoroutineContext;", "j", "Lkotlin/coroutines/CoroutineContext;", "emitContext", "", "k", "Ljava/lang/Object;", "countOrElement", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "l", "Lkotlin/jvm/functions/Function2;", "emitRef", "downstream", "<init>", "(Lo/j;Lkotlin/coroutines/CoroutineContext;)V", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
/* renamed from: p.b0 */
public final class C1875b0<T> implements C1681j<T> {
    @NotNull

    /* renamed from: j */
    public final CoroutineContext f1994j;
    @NotNull

    /* renamed from: k */
    public final Object f1995k;
    @NotNull

    /* renamed from: l */
    public final Function2<T, Continuation<? super Unit>, Object> f1996l;

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\n\n\u0002\b\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0003\u001a\u00020\u0002\"\u0004\b\u0000\u0010\u00002\u0006\u0010\u0001\u001a\u00028\u0000H@"}, mo21068d2 = {"T", "it", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.UndispatchedContextCollector$emitRef$1", mo22084f = "ChannelFlow.kt", mo22085i = {}, mo22086l = {212}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
    /* renamed from: p.b0$a */
    public static final class C1876a extends SuspendLambda implements Function2<T, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f1997j;

        /* renamed from: k */
        public /* synthetic */ Object f1998k;

        /* renamed from: l */
        public final /* synthetic */ C1681j<T> f1999l;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1876a(C1681j<? super T> jVar, Continuation<? super C1876a> continuation) {
            super(2, continuation);
            this.f1999l = jVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1876a aVar = new C1876a(this.f1999l, continuation);
            aVar.f1998k = obj;
            return aVar;
        }

        @Nullable
        public final Object invoke(T t, @Nullable Continuation<? super Unit> continuation) {
            return ((C1876a) create(t, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        @Nullable
        public final Object invokeSuspend(@NotNull Object obj) {
            Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
            int i = this.f1997j;
            if (i == 0) {
                ResultKt.throwOnFailure(obj);
                Object obj2 = this.f1998k;
                C1681j<T> jVar = this.f1999l;
                this.f1997j = 1;
                if (jVar.emit(obj2, this) == coroutine_suspended) {
                    return coroutine_suspended;
                }
            } else if (i == 1) {
                ResultKt.throwOnFailure(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return Unit.INSTANCE;
        }
    }

    public C1875b0(@NotNull C1681j<? super T> jVar, @NotNull CoroutineContext coroutineContext) {
        this.f1994j = coroutineContext;
        this.f1995k = C1996w0.m2634b(coroutineContext);
        this.f1996l = new C1876a(jVar, (Continuation<? super C1876a>) null);
    }

    @Nullable
    public Object emit(T t, @NotNull Continuation<? super Unit> continuation) {
        Object c = C1882f.m2329c(this.f1994j, t, this.f1995k, this.f1996l, continuation);
        return c == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? c : Unit.INSTANCE;
    }
}
