package p023p;

import kotlin.Metadata;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.DebugProbesKt;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.internal.DefaultConstructorMarker;
import kotlin.jvm.internal.TypeIntrinsics;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p019l.C1469m;
import p022o.C1679i;
import p022o.C1681j;
import p024q.C1996w0;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u0000*\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0005\n\u0002\u0010\u0000\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\b\u0004\u001a\u001e\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u0001H\u0000\u001a&\u0010\u0007\u001a\b\u0012\u0004\u0012\u00028\u00000\u0004\"\u0004\b\u0000\u0010\u0000*\b\u0012\u0004\u0012\u00028\u00000\u00042\u0006\u0010\u0006\u001a\u00020\u0005H\u0002\u001a]\u0010\u0010\u001a\u00028\u0000\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\b2\u0006\u0010\t\u001a\u00020\u00052\u0006\u0010\n\u001a\u00028\u00012\b\b\u0002\u0010\f\u001a\u00020\u000b2\"\u0010\u000f\u001a\u001e\b\u0001\u0012\u0004\u0012\u00028\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u000e\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\rH@ø\u0001\u0000¢\u0006\u0004\b\u0010\u0010\u0011\u0002\u0004\n\u0002\b\u0019¨\u0006\u0012"}, mo21068d2 = {"T", "Lo/i;", "Lp/e;", "b", "Lo/j;", "Lkotlin/coroutines/CoroutineContext;", "emitContext", "e", "V", "newContext", "value", "", "countOrElement", "Lkotlin/Function2;", "Lkotlin/coroutines/Continuation;", "block", "c", "(Lkotlin/coroutines/CoroutineContext;Ljava/lang/Object;Ljava/lang/Object;Lkotlin/jvm/functions/Function2;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.f */
public final class C1882f {
    @NotNull
    /* renamed from: b */
    public static final <T> C1879e<T> m2328b(@NotNull C1679i<? extends T> iVar) {
        C1879e<T> eVar = iVar instanceof C1879e ? (C1879e) iVar : null;
        return eVar == null ? new C1889i(iVar, (CoroutineContext) null, 0, (C1469m) null, 14, (DefaultConstructorMarker) null) : eVar;
    }

    /* JADX INFO: finally extract failed */
    @Nullable
    /* renamed from: c */
    public static final <T, V> Object m2329c(@NotNull CoroutineContext coroutineContext, V v, @NotNull Object obj, @NotNull Function2<? super V, ? super Continuation<? super T>, ? extends Object> function2, @NotNull Continuation<? super T> continuation) {
        Object c = C1996w0.m2635c(coroutineContext, obj);
        try {
            Object invoke = ((Function2) TypeIntrinsics.beforeCheckcastToFunctionOfArity(function2, 2)).invoke(v, new C1933z(continuation, coroutineContext));
            C1996w0.m2633a(coroutineContext, c);
            if (invoke == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()) {
                DebugProbesKt.probeCoroutineSuspended(continuation);
            }
            return invoke;
        } catch (Throwable th) {
            C1996w0.m2633a(coroutineContext, c);
            throw th;
        }
    }

    /* renamed from: d */
    public static /* synthetic */ Object m2330d(CoroutineContext coroutineContext, Object obj, Object obj2, Function2 function2, Continuation continuation, int i, Object obj3) {
        if ((i & 4) != 0) {
            obj2 = C1996w0.m2634b(coroutineContext);
        }
        return m2329c(coroutineContext, obj, obj2, function2, continuation);
    }

    /* renamed from: e */
    public static final <T> C1681j<T> m2331e(C1681j<? super T> jVar, CoroutineContext coroutineContext) {
        return jVar instanceof C1932y ? true : jVar instanceof C1922t ? jVar : new C1875b0(jVar, coroutineContext);
    }
}
