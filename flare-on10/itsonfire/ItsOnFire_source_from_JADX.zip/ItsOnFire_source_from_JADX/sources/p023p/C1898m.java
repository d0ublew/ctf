package p023p;

import java.util.concurrent.atomic.AtomicInteger;
import kotlin.Metadata;
import kotlin.PublishedApi;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.collections.IndexedValue;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.CoroutineContext;
import kotlin.coroutines.jvm.internal.ContinuationImpl;
import kotlin.coroutines.jvm.internal.DebugMetadata;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.functions.Function1;
import kotlin.jvm.functions.Function2;
import kotlin.jvm.functions.Function3;
import kotlin.jvm.internal.Lambda;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import p015j.C1232c0;
import p015j.C1353u0;
import p015j.C1362v0;
import p019l.C1448g0;
import p019l.C1455i0;
import p019l.C1470m0;
import p019l.C1472n;
import p022o.C1679i;
import p022o.C1681j;

@Metadata(mo21066bv = {}, mo21067d1 = {"\u00008\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0011\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0002\u0010\u0000\n\u0002\u0018\u0002\n\u0002\b\t\n\u0002\u0018\u0002\n\u0002\b\u0002\u001a\u0001\u0010\u000e\u001a\u00020\n\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001*\b\u0012\u0004\u0012\u00028\u00000\u00022\u0014\u0010\u0005\u001a\u0010\u0012\f\b\u0001\u0012\b\u0012\u0004\u0012\u00028\u00010\u00040\u00032\u0016\u0010\u0007\u001a\u0012\u0012\u000e\u0012\f\u0012\u0006\u0012\u0004\u0018\u00018\u0001\u0018\u00010\u00030\u000629\u0010\r\u001a5\b\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00000\u0002\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00010\u0003\u0012\n\u0012\b\u0012\u0004\u0012\u00020\n0\t\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\b¢\u0006\u0002\b\fH@ø\u0001\u0000¢\u0006\u0004\b\u000e\u0010\u000f\u001ap\u0010\u0014\u001a\b\u0012\u0004\u0012\u00028\u00020\u0004\"\u0004\b\u0000\u0010\u0010\"\u0004\b\u0001\u0010\u0011\"\u0004\b\u0002\u0010\u00002\f\u0010\u0012\u001a\b\u0012\u0004\u0012\u00028\u00000\u00042\f\u0010\u0013\u001a\b\u0012\u0004\u0012\u00028\u00010\u00042(\u0010\r\u001a$\b\u0001\u0012\u0004\u0012\u00028\u0000\u0012\u0004\u0012\u00028\u0001\u0012\n\u0012\b\u0012\u0004\u0012\u00028\u00020\t\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\bH\u0000ø\u0001\u0000¢\u0006\u0004\b\u0014\u0010\u0015*\u001c\b\u0002\u0010\u0017\"\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u00162\n\u0012\u0006\u0012\u0004\u0018\u00010\u000b0\u0016\u0002\u0004\n\u0002\b\u0019¨\u0006\u0018"}, mo21068d2 = {"R", "T", "Lo/j;", "", "Lo/i;", "flows", "Lkotlin/Function0;", "arrayFactory", "Lkotlin/Function3;", "Lkotlin/coroutines/Continuation;", "", "", "Lkotlin/ExtensionFunctionType;", "transform", "a", "(Lo/j;[Lo/i;Lkotlin/jvm/functions/Function0;Lkotlin/jvm/functions/Function3;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "T1", "T2", "flow", "flow2", "b", "(Lo/i;Lo/i;Lkotlin/jvm/functions/Function3;)Lo/i;", "Lkotlin/collections/IndexedValue;", "Update", "kotlinx-coroutines-core"}, mo21069k = 2, mo21070mv = {1, 6, 0})
/* renamed from: p.m */
public final class C1898m {

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001*\u00020\u0002H@"}, mo21068d2 = {"R", "T", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$combineInternal$2", mo22084f = "Combine.kt", mo22085i = {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2}, mo22086l = {57, 79, 82}, mo22087m = "invokeSuspend", mo22088n = {"latestValues", "resultChannel", "lastReceivedEpoch", "remainingAbsentValues", "currentEpoch", "latestValues", "resultChannel", "lastReceivedEpoch", "remainingAbsentValues", "currentEpoch", "latestValues", "resultChannel", "lastReceivedEpoch", "remainingAbsentValues", "currentEpoch"}, mo22089s = {"L$0", "L$1", "L$2", "I$0", "I$1", "L$0", "L$1", "L$2", "I$0", "I$1", "L$0", "L$1", "L$2", "I$0", "I$1"})
    /* renamed from: p.m$a */
    public static final class C1899a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public Object f2053j;

        /* renamed from: k */
        public Object f2054k;

        /* renamed from: l */
        public int f2055l;

        /* renamed from: m */
        public int f2056m;

        /* renamed from: n */
        public int f2057n;

        /* renamed from: o */
        public /* synthetic */ Object f2058o;

        /* renamed from: p */
        public final /* synthetic */ C1679i<T>[] f2059p;

        /* renamed from: q */
        public final /* synthetic */ Function0<T[]> f2060q;

        /* renamed from: r */
        public final /* synthetic */ Function3<C1681j<? super R>, T[], Continuation<? super Unit>, Object> f2061r;

        /* renamed from: s */
        public final /* synthetic */ C1681j<R> f2062s;

        @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0002\b\u0002\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0004\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001*\u00020\u0002H@"}, mo21068d2 = {"R", "T", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
        @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$combineInternal$2$1", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {34}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
        /* renamed from: p.m$a$a */
        public static final class C1900a extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

            /* renamed from: j */
            public int f2063j;

            /* renamed from: k */
            public final /* synthetic */ C1679i<T>[] f2064k;

            /* renamed from: l */
            public final /* synthetic */ int f2065l;

            /* renamed from: m */
            public final /* synthetic */ AtomicInteger f2066m;

            /* renamed from: n */
            public final /* synthetic */ C1472n<IndexedValue<Object>> f2067n;

            @Metadata(mo21067d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0005\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u00032\u0006\u0010\u0004\u001a\u0002H\u0003H@¢\u0006\u0004\b\u0005\u0010\u0006"}, mo21068d2 = {"<anonymous>", "", "R", "T", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
            /* renamed from: p.m$a$a$a */
            public static final class C1901a<T> implements C1681j {

                /* renamed from: j */
                public final /* synthetic */ C1472n<IndexedValue<Object>> f2068j;

                /* renamed from: k */
                public final /* synthetic */ int f2069k;

                @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
                @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$combineInternal$2$1$1", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {35, 36}, mo22087m = "emit", mo22088n = {}, mo22089s = {})
                /* renamed from: p.m$a$a$a$a */
                public static final class C1902a extends ContinuationImpl {

                    /* renamed from: j */
                    public /* synthetic */ Object f2070j;

                    /* renamed from: k */
                    public final /* synthetic */ C1901a<T> f2071k;

                    /* renamed from: l */
                    public int f2072l;

                    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                    public C1902a(C1901a<? super T> aVar, Continuation<? super C1902a> continuation) {
                        super(continuation);
                        this.f2071k = aVar;
                    }

                    @Nullable
                    public final Object invokeSuspend(@NotNull Object obj) {
                        this.f2070j = obj;
                        this.f2072l |= Integer.MIN_VALUE;
                        return this.f2071k.emit(null, this);
                    }
                }

                public C1901a(C1472n<IndexedValue<Object>> nVar, int i) {
                    this.f2068j = nVar;
                    this.f2069k = i;
                }

                /* JADX WARNING: Removed duplicated region for block: B:14:0x0038  */
                /* JADX WARNING: Removed duplicated region for block: B:19:0x0055 A[RETURN] */
                /* JADX WARNING: Removed duplicated region for block: B:8:0x0024  */
                @org.jetbrains.annotations.Nullable
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public final java.lang.Object emit(T r6, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super kotlin.Unit> r7) {
                    /*
                        r5 = this;
                        boolean r0 = r7 instanceof p023p.C1898m.C1899a.C1900a.C1901a.C1902a
                        if (r0 == 0) goto L_0x0013
                        r0 = r7
                        p.m$a$a$a$a r0 = (p023p.C1898m.C1899a.C1900a.C1901a.C1902a) r0
                        int r1 = r0.f2072l
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L_0x0013
                        int r1 = r1 - r2
                        r0.f2072l = r1
                        goto L_0x0018
                    L_0x0013:
                        p.m$a$a$a$a r0 = new p.m$a$a$a$a
                        r0.<init>(r5, r7)
                    L_0x0018:
                        java.lang.Object r7 = r0.f2070j
                        java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                        int r2 = r0.f2072l
                        r3 = 2
                        r4 = 1
                        if (r2 == 0) goto L_0x0038
                        if (r2 == r4) goto L_0x0034
                        if (r2 != r3) goto L_0x002c
                        kotlin.ResultKt.throwOnFailure(r7)
                        goto L_0x0056
                    L_0x002c:
                        java.lang.IllegalStateException r5 = new java.lang.IllegalStateException
                        java.lang.String r6 = "call to 'resume' before 'invoke' with coroutine"
                        r5.<init>(r6)
                        throw r5
                    L_0x0034:
                        kotlin.ResultKt.throwOnFailure(r7)
                        goto L_0x004d
                    L_0x0038:
                        kotlin.ResultKt.throwOnFailure(r7)
                        l.n<kotlin.collections.IndexedValue<java.lang.Object>> r7 = r5.f2068j
                        kotlin.collections.IndexedValue r2 = new kotlin.collections.IndexedValue
                        int r5 = r5.f2069k
                        r2.<init>(r5, r6)
                        r0.f2072l = r4
                        java.lang.Object r5 = r7.mo22824U(r2, r0)
                        if (r5 != r1) goto L_0x004d
                        return r1
                    L_0x004d:
                        r0.f2072l = r3
                        java.lang.Object r5 = p015j.C1264f4.m512a(r0)
                        if (r5 != r1) goto L_0x0056
                        return r1
                    L_0x0056:
                        kotlin.Unit r5 = kotlin.Unit.INSTANCE
                        return r5
                    */
                    throw new UnsupportedOperationException("Method not decompiled: p023p.C1898m.C1899a.C1900a.C1901a.emit(java.lang.Object, kotlin.coroutines.Continuation):java.lang.Object");
                }
            }

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1900a(C1679i<? extends T>[] iVarArr, int i, AtomicInteger atomicInteger, C1472n<IndexedValue<Object>> nVar, Continuation<? super C1900a> continuation) {
                super(2, continuation);
                this.f2064k = iVarArr;
                this.f2065l = i;
                this.f2066m = atomicInteger;
                this.f2067n = nVar;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                return new C1900a(this.f2064k, this.f2065l, this.f2066m, this.f2067n, continuation);
            }

            @Nullable
            public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
                return ((C1900a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.f2063j;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    C1679i<T>[] iVarArr = this.f2064k;
                    int i2 = this.f2065l;
                    C1679i<T> iVar = iVarArr[i2];
                    C1901a aVar = new C1901a(this.f2067n, i2);
                    this.f2063j = 1;
                    if (iVar.collect(aVar, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    try {
                        ResultKt.throwOnFailure(obj);
                    } catch (Throwable th) {
                        if (this.f2066m.decrementAndGet() == 0) {
                            C1470m0.C1471a.m1384a(this.f2067n, (Throwable) null, 1, (Object) null);
                        }
                        throw th;
                    }
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                if (this.f2066m.decrementAndGet() == 0) {
                    C1470m0.C1471a.m1384a(this.f2067n, (Throwable) null, 1, (Object) null);
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1899a(C1679i<? extends T>[] iVarArr, Function0<T[]> function0, Function3<? super C1681j<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> function3, C1681j<? super R> jVar, Continuation<? super C1899a> continuation) {
            super(2, continuation);
            this.f2059p = iVarArr;
            this.f2060q = function0;
            this.f2061r = function3;
            this.f2062s = jVar;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1899a aVar = new C1899a(this.f2059p, this.f2060q, this.f2061r, this.f2062s, continuation);
            aVar.f2058o = obj;
            return aVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1899a) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v3, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r7v12, resolved type: byte} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v12, resolved type: byte} */
        /* JADX WARNING: Multi-variable type inference failed */
        /* JADX WARNING: Removed duplicated region for block: B:25:0x00cd A[LOOP:1: B:25:0x00cd->B:31:0x00f0, LOOP_START, PHI: r3 r10 
          PHI: (r3v2 int) = (r3v1 int), (r3v3 int) binds: [B:22:0x00c8, B:31:0x00f0] A[DONT_GENERATE, DONT_INLINE]
          PHI: (r10v3 kotlin.collections.IndexedValue) = (r10v2 kotlin.collections.IndexedValue), (r10v16 kotlin.collections.IndexedValue) binds: [B:22:0x00c8, B:31:0x00f0] A[DONT_GENERATE, DONT_INLINE]] */
        @org.jetbrains.annotations.Nullable
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object invokeSuspend(@org.jetbrains.annotations.NotNull java.lang.Object r24) {
            /*
                r23 = this;
                r0 = r23
                java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r2 = r0.f2057n
                r3 = 0
                r4 = 3
                r5 = 2
                r6 = 1
                if (r2 == 0) goto L_0x0059
                if (r2 == r6) goto L_0x0037
                if (r2 == r5) goto L_0x001d
                if (r2 != r4) goto L_0x0015
                goto L_0x001d
            L_0x0015:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L_0x001d:
                int r2 = r0.f2056m
                int r3 = r0.f2055l
                java.lang.Object r7 = r0.f2054k
                byte[] r7 = (byte[]) r7
                java.lang.Object r8 = r0.f2053j
                l.n r8 = (p019l.C1472n) r8
                java.lang.Object r9 = r0.f2058o
                java.lang.Object[] r9 = (java.lang.Object[]) r9
                kotlin.ResultKt.throwOnFailure(r24)
                r13 = r3
                r14 = r9
                r3 = r2
                r2 = r7
                r7 = r8
                goto L_0x00a9
            L_0x0037:
                int r2 = r0.f2056m
                int r3 = r0.f2055l
                java.lang.Object r7 = r0.f2054k
                byte[] r7 = (byte[]) r7
                java.lang.Object r8 = r0.f2053j
                l.n r8 = (p019l.C1472n) r8
                java.lang.Object r9 = r0.f2058o
                java.lang.Object[] r9 = (java.lang.Object[]) r9
                kotlin.ResultKt.throwOnFailure(r24)
                r10 = r24
                l.r r10 = (p019l.C1488r) r10
                java.lang.Object r10 = r10.mo22894o()
                r22 = r7
                r7 = r2
                r2 = r22
                goto L_0x00c2
            L_0x0059:
                kotlin.ResultKt.throwOnFailure(r24)
                java.lang.Object r2 = r0.f2058o
                j.u0 r2 = (p015j.C1353u0) r2
                o.i<T>[] r7 = r0.f2059p
                int r13 = r7.length
                if (r13 != 0) goto L_0x0068
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            L_0x0068:
                java.lang.Object[] r14 = new java.lang.Object[r13]
                q.r0 r8 = p023p.C1923u.f2123b
                r9 = 0
                r10 = 0
                r11 = 6
                r12 = 0
                r7 = r14
                kotlin.collections.ArraysKt___ArraysJvmKt.fill$default((java.lang.Object[]) r7, (java.lang.Object) r8, (int) r9, (int) r10, (int) r11, (java.lang.Object) r12)
                r7 = 6
                r8 = 0
                l.n r21 = p019l.C1486q.m1429d(r13, r8, r8, r7, r8)
                java.util.concurrent.atomic.AtomicInteger r12 = new java.util.concurrent.atomic.AtomicInteger
                r12.<init>(r13)
                r11 = r3
            L_0x0080:
                if (r11 >= r13) goto L_0x00a5
                r8 = 0
                r9 = 0
                p.m$a$a r10 = new p.m$a$a
                o.i<T>[] r7 = r0.f2059p
                r20 = 0
                r15 = r10
                r16 = r7
                r17 = r11
                r18 = r12
                r19 = r21
                r15.<init>(r16, r17, r18, r19, r20)
                r15 = 3
                r16 = 0
                r7 = r2
                r11 = r15
                r15 = r12
                r12 = r16
                p015j.C1309n2 unused = p015j.C1292l.m571f(r7, r8, r9, r10, r11, r12)
                int r11 = r17 + 1
                r12 = r15
                goto L_0x0080
            L_0x00a5:
                byte[] r2 = new byte[r13]
                r7 = r21
            L_0x00a9:
                int r3 = r3 + r6
                byte r3 = (byte) r3
                r0.f2058o = r14
                r0.f2053j = r7
                r0.f2054k = r2
                r0.f2055l = r13
                r0.f2056m = r3
                r0.f2057n = r6
                java.lang.Object r10 = r7.mo22796z(r0)
                if (r10 != r1) goto L_0x00be
                return r1
            L_0x00be:
                r8 = r7
                r9 = r14
                r7 = r3
                r3 = r13
            L_0x00c2:
                java.lang.Object r10 = p019l.C1488r.m1442h(r10)
                kotlin.collections.IndexedValue r10 = (kotlin.collections.IndexedValue) r10
                if (r10 != 0) goto L_0x00cd
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            L_0x00cd:
                int r11 = r10.getIndex()
                r12 = r9[r11]
                java.lang.Object r10 = r10.getValue()
                r9[r11] = r10
                q.r0 r10 = p023p.C1923u.f2123b
                if (r12 != r10) goto L_0x00df
                int r3 = r3 + -1
            L_0x00df:
                byte r10 = r2[r11]
                if (r10 == r7) goto L_0x00f2
                byte r10 = (byte) r7
                r2[r11] = r10
                java.lang.Object r10 = r8.mo22794v()
                java.lang.Object r10 = p019l.C1488r.m1442h(r10)
                kotlin.collections.IndexedValue r10 = (kotlin.collections.IndexedValue) r10
                if (r10 != 0) goto L_0x00cd
            L_0x00f2:
                if (r3 != 0) goto L_0x0138
                kotlin.jvm.functions.Function0<T[]> r10 = r0.f2060q
                java.lang.Object r10 = r10.invoke()
                java.lang.Object[] r10 = (java.lang.Object[]) r10
                if (r10 != 0) goto L_0x0115
                kotlin.jvm.functions.Function3<o.j<? super R>, T[], kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> r10 = r0.f2061r
                o.j<R> r11 = r0.f2062s
                r0.f2058o = r9
                r0.f2053j = r8
                r0.f2054k = r2
                r0.f2055l = r3
                r0.f2056m = r7
                r0.f2057n = r5
                java.lang.Object r10 = r10.invoke(r11, r9, r0)
                if (r10 != r1) goto L_0x0138
                return r1
            L_0x0115:
                r13 = 0
                r14 = 0
                r15 = 0
                r16 = 14
                r17 = 0
                r11 = r9
                r12 = r10
                java.lang.Object[] unused = kotlin.collections.ArraysKt___ArraysJvmKt.copyInto$default((java.lang.Object[]) r11, (java.lang.Object[]) r12, (int) r13, (int) r14, (int) r15, (int) r16, (java.lang.Object) r17)
                kotlin.jvm.functions.Function3<o.j<? super R>, T[], kotlin.coroutines.Continuation<? super kotlin.Unit>, java.lang.Object> r11 = r0.f2061r
                o.j<R> r12 = r0.f2062s
                r0.f2058o = r9
                r0.f2053j = r8
                r0.f2054k = r2
                r0.f2055l = r3
                r0.f2056m = r7
                r0.f2057n = r4
                java.lang.Object r10 = r11.invoke(r12, r10, r0)
                if (r10 != r1) goto L_0x0138
                return r1
            L_0x0138:
                r13 = r3
                r3 = r7
                r7 = r8
                r14 = r9
                goto L_0x00a9
            */
            throw new UnsupportedOperationException("Method not decompiled: p023p.C1898m.C1899a.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0003*\u0001\u0000\b\n\u0018\u00002\b\u0012\u0004\u0012\u00028\u00000\u0001J!\u0010\u0005\u001a\u00020\u00042\f\u0010\u0003\u001a\b\u0012\u0004\u0012\u00028\u00000\u0002H@ø\u0001\u0000¢\u0006\u0004\b\u0005\u0010\u0006\u0002\u0004\n\u0002\b\u0019¨\u0006\u0007¸\u0006\u0000"}, mo21068d2 = {"p/x$b", "Lo/i;", "Lo/j;", "collector", "", "collect", "(Lo/j;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;", "kotlinx-coroutines-core"}, mo21069k = 1, mo21070mv = {1, 6, 0})
    /* renamed from: p.m$b */
    public static final class C1903b implements C1679i<R> {

        /* renamed from: j */
        public final /* synthetic */ C1679i f2073j;

        /* renamed from: k */
        public final /* synthetic */ C1679i f2074k;

        /* renamed from: l */
        public final /* synthetic */ Function3 f2075l;

        public C1903b(C1679i iVar, C1679i iVar2, Function3 function3) {
            this.f2073j = iVar;
            this.f2074k = iVar2;
            this.f2075l = function3;
        }

        @Nullable
        public Object collect(@NotNull C1681j<? super R> jVar, @NotNull Continuation<? super Unit> continuation) {
            Object g = C1362v0.m861g(new C1904c(jVar, this.f2073j, this.f2074k, this.f2075l, (Continuation<? super C1904c>) null), continuation);
            return g == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? g : Unit.INSTANCE;
        }
    }

    @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u000e\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0002\n\u0000\u0010\u0005\u001a\u00020\u0004\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001\"\u0004\b\u0002\u0010\u0002*\u00020\u0003H@"}, mo21068d2 = {"T1", "T2", "R", "Lj/u0;", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
    @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1", mo22084f = "Combine.kt", mo22085i = {0}, mo22086l = {129}, mo22087m = "invokeSuspend", mo22088n = {"second"}, mo22089s = {"L$0"})
    /* renamed from: p.m$c */
    public static final class C1904c extends SuspendLambda implements Function2<C1353u0, Continuation<? super Unit>, Object> {

        /* renamed from: j */
        public int f2076j;

        /* renamed from: k */
        public /* synthetic */ Object f2077k;

        /* renamed from: l */
        public final /* synthetic */ C1681j<R> f2078l;

        /* renamed from: m */
        public final /* synthetic */ C1679i<T2> f2079m;

        /* renamed from: n */
        public final /* synthetic */ C1679i<T1> f2080n;

        /* renamed from: o */
        public final /* synthetic */ Function3<T1, T2, Continuation<? super R>, Object> f2081o;

        @Metadata(mo21067d1 = {"\u0000\u0010\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0004\n\u0002\u0010\u0003\n\u0000\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u00042\b\u0010\u0005\u001a\u0004\u0018\u00010\u0006H\n¢\u0006\u0002\b\u0007"}, mo21068d2 = {"<anonymous>", "", "T1", "T2", "R", "it", "", "invoke"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
        /* renamed from: p.m$c$a */
        public static final class C1905a extends Lambda implements Function1<Throwable, Unit> {

            /* renamed from: j */
            public final /* synthetic */ C1232c0 f2082j;

            /* renamed from: k */
            public final /* synthetic */ C1681j<R> f2083k;

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1905a(C1232c0 c0Var, C1681j<? super R> jVar) {
                super(1);
                this.f2082j = c0Var;
                this.f2083k = jVar;
            }

            public /* bridge */ /* synthetic */ Object invoke(Object obj) {
                invoke((Throwable) obj);
                return Unit.INSTANCE;
            }

            public final void invoke(@Nullable Throwable th) {
                if (this.f2082j.mo21543b()) {
                    this.f2082j.cancel(new C1872a(this.f2083k));
                }
            }
        }

        @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\f\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0005\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001\"\u0004\b\u0002\u0010\u00022\u0006\u0010\u0004\u001a\u00020\u0003H@"}, mo21068d2 = {"T1", "T2", "R", "", "it", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
        @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1$2", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {130}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
        /* renamed from: p.m$c$b */
        public static final class C1906b extends SuspendLambda implements Function2<Unit, Continuation<? super Unit>, Object> {

            /* renamed from: j */
            public int f2084j;

            /* renamed from: k */
            public final /* synthetic */ C1679i<T1> f2085k;

            /* renamed from: l */
            public final /* synthetic */ CoroutineContext f2086l;

            /* renamed from: m */
            public final /* synthetic */ Object f2087m;

            /* renamed from: n */
            public final /* synthetic */ C1455i0<Object> f2088n;

            /* renamed from: o */
            public final /* synthetic */ C1681j<R> f2089o;

            /* renamed from: p */
            public final /* synthetic */ Function3<T1, T2, Continuation<? super R>, Object> f2090p;

            @Metadata(mo21067d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u00042\u0006\u0010\u0005\u001a\u0002H\u0002H@¢\u0006\u0004\b\u0006\u0010\u0007"}, mo21068d2 = {"<anonymous>", "", "T1", "T2", "R", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
            /* renamed from: p.m$c$b$a */
            public static final class C1907a<T> implements C1681j {

                /* renamed from: j */
                public final /* synthetic */ CoroutineContext f2091j;

                /* renamed from: k */
                public final /* synthetic */ Object f2092k;

                /* renamed from: l */
                public final /* synthetic */ C1455i0<Object> f2093l;

                /* renamed from: m */
                public final /* synthetic */ C1681j<R> f2094m;

                /* renamed from: n */
                public final /* synthetic */ Function3<T1, T2, Continuation<? super R>, Object> f2095n;

                @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\f\n\u0002\b\u0003\n\u0002\u0010\u0002\n\u0002\b\u0002\u0010\u0005\u001a\u00020\u0003\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001\"\u0004\b\u0002\u0010\u00022\u0006\u0010\u0004\u001a\u00020\u0003H@"}, mo21068d2 = {"T1", "T2", "R", "", "it", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
                @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1$2$1$1", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {132, 135, 135}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
                /* renamed from: p.m$c$b$a$a */
                public static final class C1908a extends SuspendLambda implements Function2<Unit, Continuation<? super Unit>, Object> {

                    /* renamed from: j */
                    public Object f2096j;

                    /* renamed from: k */
                    public int f2097k;

                    /* renamed from: l */
                    public final /* synthetic */ C1455i0<Object> f2098l;

                    /* renamed from: m */
                    public final /* synthetic */ C1681j<R> f2099m;

                    /* renamed from: n */
                    public final /* synthetic */ Function3<T1, T2, Continuation<? super R>, Object> f2100n;

                    /* renamed from: o */
                    public final /* synthetic */ T1 f2101o;

                    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                    public C1908a(C1455i0<? extends Object> i0Var, C1681j<? super R> jVar, Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> function3, T1 t1, Continuation<? super C1908a> continuation) {
                        super(2, continuation);
                        this.f2098l = i0Var;
                        this.f2099m = jVar;
                        this.f2100n = function3;
                        this.f2101o = t1;
                    }

                    @NotNull
                    public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                        return new C1908a(this.f2098l, this.f2099m, this.f2100n, this.f2101o, continuation);
                    }

                    @Nullable
                    public final Object invoke(@NotNull Unit unit, @Nullable Continuation<? super Unit> continuation) {
                        return ((C1908a) create(unit, continuation)).invokeSuspend(Unit.INSTANCE);
                    }

                    /* JADX WARNING: Removed duplicated region for block: B:27:0x006e A[RETURN] */
                    @org.jetbrains.annotations.Nullable
                    /* Code decompiled incorrectly, please refer to instructions dump. */
                    public final java.lang.Object invokeSuspend(@org.jetbrains.annotations.NotNull java.lang.Object r9) {
                        /*
                            r8 = this;
                            java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                            int r1 = r8.f2097k
                            r2 = 0
                            r3 = 3
                            r4 = 2
                            r5 = 1
                            if (r1 == 0) goto L_0x0030
                            if (r1 == r5) goto L_0x0026
                            if (r1 == r4) goto L_0x001e
                            if (r1 != r3) goto L_0x0016
                            kotlin.ResultKt.throwOnFailure(r9)
                            goto L_0x006f
                        L_0x0016:
                            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
                            java.lang.String r9 = "call to 'resume' before 'invoke' with coroutine"
                            r8.<init>(r9)
                            throw r8
                        L_0x001e:
                            java.lang.Object r1 = r8.f2096j
                            o.j r1 = (p022o.C1681j) r1
                            kotlin.ResultKt.throwOnFailure(r9)
                            goto L_0x0064
                        L_0x0026:
                            kotlin.ResultKt.throwOnFailure(r9)
                            l.r r9 = (p019l.C1488r) r9
                            java.lang.Object r9 = r9.mo22894o()
                            goto L_0x003e
                        L_0x0030:
                            kotlin.ResultKt.throwOnFailure(r9)
                            l.i0<java.lang.Object> r9 = r8.f2098l
                            r8.f2097k = r5
                            java.lang.Object r9 = r9.mo22796z(r8)
                            if (r9 != r0) goto L_0x003e
                            return r0
                        L_0x003e:
                            o.j<R> r1 = r8.f2099m
                            boolean r5 = r9 instanceof p019l.C1488r.C1491c
                            if (r5 == 0) goto L_0x0050
                            java.lang.Throwable r8 = p019l.C1488r.m1440f(r9)
                            if (r8 != 0) goto L_0x004f
                            p.a r8 = new p.a
                            r8.<init>(r1)
                        L_0x004f:
                            throw r8
                        L_0x0050:
                            kotlin.jvm.functions.Function3<T1, T2, kotlin.coroutines.Continuation<? super R>, java.lang.Object> r5 = r8.f2100n
                            T1 r6 = r8.f2101o
                            q.r0 r7 = p023p.C1923u.f2122a
                            if (r9 != r7) goto L_0x0059
                            r9 = r2
                        L_0x0059:
                            r8.f2096j = r1
                            r8.f2097k = r4
                            java.lang.Object r9 = r5.invoke(r6, r9, r8)
                            if (r9 != r0) goto L_0x0064
                            return r0
                        L_0x0064:
                            r8.f2096j = r2
                            r8.f2097k = r3
                            java.lang.Object r8 = r1.emit(r9, r8)
                            if (r8 != r0) goto L_0x006f
                            return r0
                        L_0x006f:
                            kotlin.Unit r8 = kotlin.Unit.INSTANCE
                            return r8
                        */
                        throw new UnsupportedOperationException("Method not decompiled: p023p.C1898m.C1904c.C1906b.C1907a.C1908a.invokeSuspend(java.lang.Object):java.lang.Object");
                    }
                }

                @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
                @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1$2$1", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {131}, mo22087m = "emit", mo22088n = {}, mo22089s = {})
                /* renamed from: p.m$c$b$a$b */
                public static final class C1909b extends ContinuationImpl {

                    /* renamed from: j */
                    public /* synthetic */ Object f2102j;

                    /* renamed from: k */
                    public final /* synthetic */ C1907a<T> f2103k;

                    /* renamed from: l */
                    public int f2104l;

                    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                    public C1909b(C1907a<? super T> aVar, Continuation<? super C1909b> continuation) {
                        super(continuation);
                        this.f2103k = aVar;
                    }

                    @Nullable
                    public final Object invokeSuspend(@NotNull Object obj) {
                        this.f2102j = obj;
                        this.f2104l |= Integer.MIN_VALUE;
                        return this.f2103k.emit(null, this);
                    }
                }

                public C1907a(CoroutineContext coroutineContext, Object obj, C1455i0<? extends Object> i0Var, C1681j<? super R> jVar, Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> function3) {
                    this.f2091j = coroutineContext;
                    this.f2092k = obj;
                    this.f2093l = i0Var;
                    this.f2094m = jVar;
                    this.f2095n = function3;
                }

                /* JADX WARNING: Removed duplicated region for block: B:12:0x0031  */
                /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
                @org.jetbrains.annotations.Nullable
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public final java.lang.Object emit(T1 r13, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super kotlin.Unit> r14) {
                    /*
                        r12 = this;
                        boolean r0 = r14 instanceof p023p.C1898m.C1904c.C1906b.C1907a.C1909b
                        if (r0 == 0) goto L_0x0013
                        r0 = r14
                        p.m$c$b$a$b r0 = (p023p.C1898m.C1904c.C1906b.C1907a.C1909b) r0
                        int r1 = r0.f2104l
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L_0x0013
                        int r1 = r1 - r2
                        r0.f2104l = r1
                        goto L_0x0018
                    L_0x0013:
                        p.m$c$b$a$b r0 = new p.m$c$b$a$b
                        r0.<init>(r12, r14)
                    L_0x0018:
                        java.lang.Object r14 = r0.f2102j
                        java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                        int r2 = r0.f2104l
                        r3 = 1
                        if (r2 == 0) goto L_0x0031
                        if (r2 != r3) goto L_0x0029
                        kotlin.ResultKt.throwOnFailure(r14)
                        goto L_0x0051
                    L_0x0029:
                        java.lang.IllegalStateException r12 = new java.lang.IllegalStateException
                        java.lang.String r13 = "call to 'resume' before 'invoke' with coroutine"
                        r12.<init>(r13)
                        throw r12
                    L_0x0031:
                        kotlin.ResultKt.throwOnFailure(r14)
                        kotlin.coroutines.CoroutineContext r14 = r12.f2091j
                        kotlin.Unit r2 = kotlin.Unit.INSTANCE
                        java.lang.Object r4 = r12.f2092k
                        p.m$c$b$a$a r11 = new p.m$c$b$a$a
                        l.i0<java.lang.Object> r6 = r12.f2093l
                        o.j<R> r7 = r12.f2094m
                        kotlin.jvm.functions.Function3<T1, T2, kotlin.coroutines.Continuation<? super R>, java.lang.Object> r8 = r12.f2095n
                        r10 = 0
                        r5 = r11
                        r9 = r13
                        r5.<init>(r6, r7, r8, r9, r10)
                        r0.f2104l = r3
                        java.lang.Object r12 = p023p.C1882f.m2329c(r14, r2, r4, r11, r0)
                        if (r12 != r1) goto L_0x0051
                        return r1
                    L_0x0051:
                        kotlin.Unit r12 = kotlin.Unit.INSTANCE
                        return r12
                    */
                    throw new UnsupportedOperationException("Method not decompiled: p023p.C1898m.C1904c.C1906b.C1907a.emit(java.lang.Object, kotlin.coroutines.Continuation):java.lang.Object");
                }
            }

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1906b(C1679i<? extends T1> iVar, CoroutineContext coroutineContext, Object obj, C1455i0<? extends Object> i0Var, C1681j<? super R> jVar, Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> function3, Continuation<? super C1906b> continuation) {
                super(2, continuation);
                this.f2085k = iVar;
                this.f2086l = coroutineContext;
                this.f2087m = obj;
                this.f2088n = i0Var;
                this.f2089o = jVar;
                this.f2090p = function3;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                return new C1906b(this.f2085k, this.f2086l, this.f2087m, this.f2088n, this.f2089o, this.f2090p, continuation);
            }

            @Nullable
            public final Object invoke(@NotNull Unit unit, @Nullable Continuation<? super Unit> continuation) {
                return ((C1906b) create(unit, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.f2084j;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    C1679i<T1> iVar = this.f2085k;
                    C1907a aVar = new C1907a(this.f2086l, this.f2087m, this.f2088n, this.f2089o, this.f2090p);
                    this.f2084j = 1;
                    if (iVar.collect(aVar, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        @Metadata(mo21066bv = {}, mo21067d1 = {"\u0000\u0012\n\u0002\b\u0003\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0010\u0002\n\u0000\u0010\u0006\u001a\u00020\u0005\"\u0004\b\u0000\u0010\u0000\"\u0004\b\u0001\u0010\u0001\"\u0004\b\u0002\u0010\u0002*\b\u0012\u0004\u0012\u00020\u00040\u0003H@"}, mo21068d2 = {"T1", "T2", "R", "Ll/g0;", "", "", "<anonymous>"}, mo21069k = 3, mo21070mv = {1, 6, 0})
        @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1$second$1", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {92}, mo22087m = "invokeSuspend", mo22088n = {}, mo22089s = {})
        /* renamed from: p.m$c$c */
        public static final class C1910c extends SuspendLambda implements Function2<C1448g0<? super Object>, Continuation<? super Unit>, Object> {

            /* renamed from: j */
            public int f2105j;

            /* renamed from: k */
            public /* synthetic */ Object f2106k;

            /* renamed from: l */
            public final /* synthetic */ C1679i<T2> f2107l;

            @Metadata(mo21067d1 = {"\u0000\n\n\u0000\n\u0002\u0010\u0002\n\u0002\b\u0006\u0010\u0000\u001a\u00020\u0001\"\u0004\b\u0000\u0010\u0002\"\u0004\b\u0001\u0010\u0003\"\u0004\b\u0002\u0010\u00042\u0006\u0010\u0005\u001a\u0002H\u0003H@¢\u0006\u0004\b\u0006\u0010\u0007"}, mo21068d2 = {"<anonymous>", "", "T1", "T2", "R", "value", "emit", "(Ljava/lang/Object;Lkotlin/coroutines/Continuation;)Ljava/lang/Object;"}, mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
            /* renamed from: p.m$c$c$a */
            public static final class C1911a<T> implements C1681j {

                /* renamed from: j */
                public final /* synthetic */ C1448g0<Object> f2108j;

                @Metadata(mo21069k = 3, mo21070mv = {1, 6, 0}, mo21072xi = 48)
                @DebugMetadata(mo22083c = "kotlinx.coroutines.flow.internal.CombineKt$zipImpl$1$1$second$1$1", mo22084f = "Combine.kt", mo22085i = {}, mo22086l = {93}, mo22087m = "emit", mo22088n = {}, mo22089s = {})
                /* renamed from: p.m$c$c$a$a */
                public static final class C1912a extends ContinuationImpl {

                    /* renamed from: j */
                    public /* synthetic */ Object f2109j;

                    /* renamed from: k */
                    public final /* synthetic */ C1911a<T> f2110k;

                    /* renamed from: l */
                    public int f2111l;

                    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
                    public C1912a(C1911a<? super T> aVar, Continuation<? super C1912a> continuation) {
                        super(continuation);
                        this.f2110k = aVar;
                    }

                    @Nullable
                    public final Object invokeSuspend(@NotNull Object obj) {
                        this.f2109j = obj;
                        this.f2111l |= Integer.MIN_VALUE;
                        return this.f2110k.emit(null, this);
                    }
                }

                public C1911a(C1448g0<Object> g0Var) {
                    this.f2108j = g0Var;
                }

                /* JADX WARNING: Removed duplicated region for block: B:12:0x0031  */
                /* JADX WARNING: Removed duplicated region for block: B:8:0x0023  */
                @org.jetbrains.annotations.Nullable
                /* Code decompiled incorrectly, please refer to instructions dump. */
                public final java.lang.Object emit(T2 r5, @org.jetbrains.annotations.NotNull kotlin.coroutines.Continuation<? super kotlin.Unit> r6) {
                    /*
                        r4 = this;
                        boolean r0 = r6 instanceof p023p.C1898m.C1904c.C1910c.C1911a.C1912a
                        if (r0 == 0) goto L_0x0013
                        r0 = r6
                        p.m$c$c$a$a r0 = (p023p.C1898m.C1904c.C1910c.C1911a.C1912a) r0
                        int r1 = r0.f2111l
                        r2 = -2147483648(0xffffffff80000000, float:-0.0)
                        r3 = r1 & r2
                        if (r3 == 0) goto L_0x0013
                        int r1 = r1 - r2
                        r0.f2111l = r1
                        goto L_0x0018
                    L_0x0013:
                        p.m$c$c$a$a r0 = new p.m$c$c$a$a
                        r0.<init>(r4, r6)
                    L_0x0018:
                        java.lang.Object r6 = r0.f2109j
                        java.lang.Object r1 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                        int r2 = r0.f2111l
                        r3 = 1
                        if (r2 == 0) goto L_0x0031
                        if (r2 != r3) goto L_0x0029
                        kotlin.ResultKt.throwOnFailure(r6)
                        goto L_0x0047
                    L_0x0029:
                        java.lang.IllegalStateException r4 = new java.lang.IllegalStateException
                        java.lang.String r5 = "call to 'resume' before 'invoke' with coroutine"
                        r4.<init>(r5)
                        throw r4
                    L_0x0031:
                        kotlin.ResultKt.throwOnFailure(r6)
                        l.g0<java.lang.Object> r4 = r4.f2108j
                        l.m0 r4 = r4.mo22857c()
                        if (r5 != 0) goto L_0x003e
                        q.r0 r5 = p023p.C1923u.f2122a
                    L_0x003e:
                        r0.f2111l = r3
                        java.lang.Object r4 = r4.mo22824U(r5, r0)
                        if (r4 != r1) goto L_0x0047
                        return r1
                    L_0x0047:
                        kotlin.Unit r4 = kotlin.Unit.INSTANCE
                        return r4
                    */
                    throw new UnsupportedOperationException("Method not decompiled: p023p.C1898m.C1904c.C1910c.C1911a.emit(java.lang.Object, kotlin.coroutines.Continuation):java.lang.Object");
                }
            }

            /* JADX INFO: super call moved to the top of the method (can break code semantics) */
            public C1910c(C1679i<? extends T2> iVar, Continuation<? super C1910c> continuation) {
                super(2, continuation);
                this.f2107l = iVar;
            }

            @NotNull
            public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
                C1910c cVar = new C1910c(this.f2107l, continuation);
                cVar.f2106k = obj;
                return cVar;
            }

            @Nullable
            public final Object invoke(@NotNull C1448g0<Object> g0Var, @Nullable Continuation<? super Unit> continuation) {
                return ((C1910c) create(g0Var, continuation)).invokeSuspend(Unit.INSTANCE);
            }

            @Nullable
            public final Object invokeSuspend(@NotNull Object obj) {
                Object coroutine_suspended = IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED();
                int i = this.f2105j;
                if (i == 0) {
                    ResultKt.throwOnFailure(obj);
                    C1679i<T2> iVar = this.f2107l;
                    C1911a aVar = new C1911a((C1448g0) this.f2106k);
                    this.f2105j = 1;
                    if (iVar.collect(aVar, this) == coroutine_suspended) {
                        return coroutine_suspended;
                    }
                } else if (i == 1) {
                    ResultKt.throwOnFailure(obj);
                } else {
                    throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
                }
                return Unit.INSTANCE;
            }
        }

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C1904c(C1681j<? super R> jVar, C1679i<? extends T2> iVar, C1679i<? extends T1> iVar2, Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> function3, Continuation<? super C1904c> continuation) {
            super(2, continuation);
            this.f2078l = jVar;
            this.f2079m = iVar;
            this.f2080n = iVar2;
            this.f2081o = function3;
        }

        @NotNull
        public final Continuation<Unit> create(@Nullable Object obj, @NotNull Continuation<?> continuation) {
            C1904c cVar = new C1904c(this.f2078l, this.f2079m, this.f2080n, this.f2081o, continuation);
            cVar.f2077k = obj;
            return cVar;
        }

        @Nullable
        public final Object invoke(@NotNull C1353u0 u0Var, @Nullable Continuation<? super Unit> continuation) {
            return ((C1904c) create(u0Var, continuation)).invokeSuspend(Unit.INSTANCE);
        }

        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r0v12, resolved type: java.lang.Object} */
        /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v13, resolved type: l.i0} */
        /* JADX WARNING: Multi-variable type inference failed */
        @org.jetbrains.annotations.Nullable
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public final java.lang.Object invokeSuspend(@org.jetbrains.annotations.NotNull java.lang.Object r20) {
            /*
                r19 = this;
                r8 = r19
                java.lang.Object r0 = kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED()
                int r1 = r8.f2076j
                r9 = 1
                r10 = 0
                if (r1 == 0) goto L_0x0026
                if (r1 != r9) goto L_0x001e
                java.lang.Object r0 = r8.f2077k
                r1 = r0
                l.i0 r1 = (p019l.C1455i0) r1
                kotlin.ResultKt.throwOnFailure(r20)     // Catch:{ a -> 0x001b }
                goto L_0x0086
            L_0x0018:
                r0 = move-exception
                goto L_0x009e
            L_0x001b:
                r0 = move-exception
                goto L_0x0095
            L_0x001e:
                java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
                java.lang.String r1 = "call to 'resume' before 'invoke' with coroutine"
                r0.<init>(r1)
                throw r0
            L_0x0026:
                kotlin.ResultKt.throwOnFailure(r20)
                java.lang.Object r1 = r8.f2077k
                j.u0 r1 = (p015j.C1353u0) r1
                r3 = 0
                r4 = 0
                p.m$c$c r5 = new p.m$c$c
                o.i<T2> r2 = r8.f2079m
                r5.<init>(r2, r10)
                r6 = 3
                r7 = 0
                r2 = r1
                l.i0 r7 = p019l.C1439e0.m1249g(r2, r3, r4, r5, r6, r7)
                j.c0 r2 = p015j.C1350t2.m791c(r10, r9, r10)
                r3 = r7
                l.m0 r3 = (p019l.C1470m0) r3
                p.m$c$a r4 = new p.m$c$a
                o.j<R> r5 = r8.f2078l
                r4.<init>(r2, r5)
                r3.mo22833Q(r4)
                kotlin.coroutines.CoroutineContext r13 = r1.getCoroutineContext()     // Catch:{ a -> 0x0092, all -> 0x008e }
                java.lang.Object r14 = p024q.C1996w0.m2634b(r13)     // Catch:{ a -> 0x0092, all -> 0x008e }
                kotlin.coroutines.CoroutineContext r1 = r1.getCoroutineContext()     // Catch:{ a -> 0x0092, all -> 0x008e }
                kotlin.coroutines.CoroutineContext r1 = r1.plus(r2)     // Catch:{ a -> 0x0092, all -> 0x008e }
                kotlin.Unit r2 = kotlin.Unit.INSTANCE     // Catch:{ a -> 0x0092, all -> 0x008e }
                r3 = 0
                p.m$c$b r4 = new p.m$c$b     // Catch:{ a -> 0x0092, all -> 0x008e }
                o.i<T1> r12 = r8.f2080n     // Catch:{ a -> 0x0092, all -> 0x008e }
                o.j<R> r5 = r8.f2078l     // Catch:{ a -> 0x0092, all -> 0x008e }
                kotlin.jvm.functions.Function3<T1, T2, kotlin.coroutines.Continuation<? super R>, java.lang.Object> r6 = r8.f2081o     // Catch:{ a -> 0x0092, all -> 0x008e }
                r18 = 0
                r11 = r4
                r15 = r7
                r16 = r5
                r17 = r6
                r11.<init>(r12, r13, r14, r15, r16, r17, r18)     // Catch:{ a -> 0x0092, all -> 0x008e }
                r6 = 4
                r11 = 0
                r8.f2077k = r7     // Catch:{ a -> 0x0092, all -> 0x008e }
                r8.f2076j = r9     // Catch:{ a -> 0x0092, all -> 0x008e }
                r5 = r19
                r12 = r7
                r7 = r11
                java.lang.Object r1 = p023p.C1882f.m2330d(r1, r2, r3, r4, r5, r6, r7)     // Catch:{ a -> 0x008c, all -> 0x008a }
                if (r1 != r0) goto L_0x0085
                return r0
            L_0x0085:
                r1 = r12
            L_0x0086:
                p019l.C1455i0.C1456a.m1334b(r1, r10, r9, r10)
                goto L_0x009b
            L_0x008a:
                r0 = move-exception
                goto L_0x0090
            L_0x008c:
                r0 = move-exception
                goto L_0x0094
            L_0x008e:
                r0 = move-exception
                r12 = r7
            L_0x0090:
                r1 = r12
                goto L_0x009e
            L_0x0092:
                r0 = move-exception
                r12 = r7
            L_0x0094:
                r1 = r12
            L_0x0095:
                o.j<R> r2 = r8.f2078l     // Catch:{ all -> 0x0018 }
                p023p.C1918q.m2358b(r0, r2)     // Catch:{ all -> 0x0018 }
                goto L_0x0086
            L_0x009b:
                kotlin.Unit r0 = kotlin.Unit.INSTANCE
                return r0
            L_0x009e:
                p019l.C1455i0.C1456a.m1334b(r1, r10, r9, r10)
                throw r0
            */
            throw new UnsupportedOperationException("Method not decompiled: p023p.C1898m.C1904c.invokeSuspend(java.lang.Object):java.lang.Object");
        }
    }

    @Nullable
    @PublishedApi
    /* renamed from: a */
    public static final <R, T> Object m2352a(@NotNull C1681j<? super R> jVar, @NotNull C1679i<? extends T>[] iVarArr, @NotNull Function0<T[]> function0, @NotNull Function3<? super C1681j<? super R>, ? super T[], ? super Continuation<? super Unit>, ? extends Object> function3, @NotNull Continuation<? super Unit> continuation) {
        Object a = C1915p.m2355a(new C1899a(iVarArr, function0, function3, jVar, (Continuation<? super C1899a>) null), continuation);
        return a == IntrinsicsKt__IntrinsicsKt.getCOROUTINE_SUSPENDED() ? a : Unit.INSTANCE;
    }

    @NotNull
    /* renamed from: b */
    public static final <T1, T2, R> C1679i<R> m2353b(@NotNull C1679i<? extends T1> iVar, @NotNull C1679i<? extends T2> iVar2, @NotNull Function3<? super T1, ? super T2, ? super Continuation<? super R>, ? extends Object> function3) {
        return new C1903b(iVar2, iVar, function3);
    }
}
