the password is obfuscated into `a[x] + a[y] + a[z] + ...`
